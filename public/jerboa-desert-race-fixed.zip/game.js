(() => {
  // src/game/rules.ts
  var W = 1280;
  var H = 720;
  var HORIZON_Y = 512;
  var GROUND = 642;
  var START_X = 430;
  var PPM = 15;
  var RACE_LEN = 850;
  var LANE_DY = [0, 32, 64, 94];
  var LANE_SCALE = [0.74, 0.7, 0.66, 0.62];
  var GRAV = 2600;
  var JUMP_V = 900;
  var BASE_SPEED = 24;
  var FLOW_STEP = 0.045;
  var SPRINT_MULT = 1.28;
  var PERFECT_WINDOW = 0.22;
  var TAU = Math.PI * 2;
  function getLaneGroundY(lane) {
    const idx = clamp(Math.round(lane || 0), 0, LANE_DY.length - 1);
    return GROUND - LANE_DY[idx];
  }
  var PLAYER_SKINS = [
    {
      id: "teal",
      title: "\u0411\u0438\u0440\u044E\u0437\u043E\u0432\u044B\u0439 \u0412\u0435\u0442\u0435\u0440",
      scarf: "#28b5a8",
      goggle: "#3de0d0",
      coatColor: "#f3d9a6",
      furTint: "#eb9238"
    },
    {
      id: "gold",
      title: "\u0417\u043E\u043B\u043E\u0442\u043E\u0439 \u0421\u0430\u043C\u0443\u043C",
      scarf: "#f5a623",
      goggle: "#ffe066",
      coatColor: "#fff0c4",
      furTint: "#f09c3e"
    },
    {
      id: "crimson",
      title: "\u0410\u043B\u044B\u0439 \u041C\u0438\u0440\u0430\u0436",
      scarf: "#e03e52",
      goggle: "#ff7588",
      coatColor: "#edd2b0",
      furTint: "#d97b29"
    },
    {
      id: "emerald",
      title: "\u0418\u0437\u0443\u043C\u0440\u0443\u0434\u043D\u044B\u0439 \u041E\u0430\u0437\u0438\u0441",
      scarf: "#2bb673",
      goggle: "#6bffb8",
      coatColor: "#e8dec0",
      furTint: "#e38834"
    }
  ];
  function clamp(v, a, b) {
    return v < a ? a : v > b ? b : v;
  }
  function lerp(a, b, t) {
    return a + (b - a) * t;
  }
  function mulberry32(a) {
    let state = a | 0;
    return function() {
      state = state + 1831565813 | 0;
      let t = Math.imul(state ^ state >>> 15, 1 | state);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function hash01(n) {
    const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
  }
  function buildTrack(seed) {
    const rnd = mulberry32(seed);
    const list = [];
    let x = 130;
    while (x < RACE_LEN - 70) {
      const r = rnd();
      const type = r < 0.34 ? "rock" : r < 0.78 ? "cactus" : "bush";
      let h;
      if (type === "rock") h = 48 + rnd() * 30;
      else if (type === "cactus") h = 92 + rnd() * 34;
      else h = 58 + rnd() * 22;
      list.push({
        x,
        w: type === "rock" ? 2.4 : 1.7,
        h,
        type,
        seed: rnd() * 100,
        hits: 0
      });
      x += 54 + rnd() * 54;
    }
    return list;
  }
  function nextObstacleAhead(obstacles, x, maxDist) {
    for (let i = 0; i < obstacles.length; i++) {
      const o = obstacles[i];
      if (o.x + o.w * 0.5 > x - 2 && o.x - x < maxDist) return o;
    }
    return null;
  }
  function createRacer(name, isPlayer, base, skill, scarf, goggle, coatColor, furTint, startX, seed, lane) {
    const rng = mulberry32(seed * 7919 + 13);
    return {
      name,
      isPlayer,
      base,
      aiSkill: skill,
      scarf,
      goggle,
      coatColor,
      furTint,
      startX,
      rng,
      phase: rng() * TAU,
      seedT: rng() * 20,
      x: startX,
      speed: 0,
      h: 0,
      vh: 0,
      airborne: false,
      stumble: 0,
      flow: 0,
      stamina: 100,
      staminaGhost: 100,
      squash: 1,
      lastLand: -9,
      earlyJump: 0,
      coyoteTime: 0,
      dustT: 0,
      finished: false,
      finishTime: 0,
      place: 1,
      aiDecidedFor: null,
      aiWillJump: false,
      aiJumpGap: 6,
      sprintCd: 0,
      sprintFx: 0,
      combo: 0,
      lane
    };
  }
  function createRacers(skinIndex = 0) {
    const skin = PLAYER_SKINS[skinIndex % PLAYER_SKINS.length] || PLAYER_SKINS[0];
    const player = createRacer(
      "\u0422\u044B",
      true,
      BASE_SPEED,
      1,
      skin.scarf,
      skin.goggle,
      skin.coatColor,
      skin.furTint,
      0,
      1,
      0
    );
    const defs = [
      ["\u0412\u0438\u0445\u0440\u044C", 25.7, 0.9, "#e04f44", "#ff7369", "#ebd09e", "#e28432", -10, 2, 1],
      ["\u041F\u0440\u044B\u0433\u0443\u043D", 25.2, 0.82, "#447ce0", "#6ea2ff", "#e5cfa6", "#df8c3d", -20, 3, 2],
      ["\u041F\u0435\u0441\u0447\u0438\u043D\u043A\u0430", 24.7, 0.74, "#9462de", "#b88aff", "#f0d8b4", "#ed9947", -30, 4, 3]
    ];
    const racers = [player];
    for (let i = 0; i < defs.length; i++) {
      const d = defs[i];
      racers.push(createRacer(d[0], false, d[1], d[2], d[3], d[4], d[5], d[6], d[7], d[8], d[9]));
    }
    return { racers, player };
  }
  function executeJump(r, perfect) {
    r.airborne = true;
    r.vh = JUMP_V * (perfect ? 1.05 : 1);
    r.h = 0.5;
    r.squash = 1.16;
    r.earlyJump = 0;
    r.coyoteTime = 0;
    if (perfect) {
      r.flow = Math.min(5, r.flow + 1);
      r.combo = (r.combo || 0) + 1;
    }
  }
  function executeLand(r, raceTime) {
    r.lastLand = raceTime;
    r.airborne = false;
    r.vh = 0;
    r.h = 0;
    r.squash = 0.78;
    if (r.earlyJump > 0 && !r.finished) {
      r.earlyJump = 0;
      executeJump(r, true);
      return { autoHopped: true };
    }
    r.earlyJump = 0;
    r.flow = Math.max(0, r.flow - 0.42);
    r.combo = 0;
    return { autoHopped: false };
  }
  function settleFinishedRacer(r, dt, raceTime) {
    let landed = false;
    r.speed *= Math.max(0, 1 - dt * 1.45);
    if (r.speed < 0.2) r.speed = 0;
    r.x += r.speed * dt;
    r.squash += (1 - r.squash) * Math.min(1, dt * 8);
    if (r.airborne || r.h > 0) {
      r.vh -= GRAV * dt;
      r.h += r.vh * dt;
      r.phase += dt * 2;
      if (r.h <= 0) {
        r.h = 0;
        r.vh = 0;
        r.airborne = false;
        r.earlyJump = 0;
        r.lastLand = raceTime;
        r.squash = 0.8;
        landed = true;
      }
    } else {
      r.h = 0;
      r.vh = 0;
      if (r.speed > 0.5) {
        r.phase += dt * (2.5 + r.speed * 0.28);
      }
    }
    return landed;
  }
  function applyObstacleHit(r, o) {
    r.stumble = 0.95;
    r.speed *= 0.28;
    r.h = 0;
    r.vh = 0;
    r.airborne = false;
    r.flow = 0;
    r.combo = 0;
    r.squash = 0.72;
    o.hits++;
  }
  function checkRacerObstacles(r, obstacles) {
    if (r.stumble > 0 || r.finished) return null;
    for (let i = 0; i < obstacles.length; i++) {
      const o = obstacles[i];
      if (Math.abs(o.x - (r.x + 1.1)) < o.w * 0.5 + 0.5) {
        if (r.h < o.h - 10) {
          applyObstacleHit(r, o);
          return o;
        }
        break;
      }
    }
    return null;
  }
  function advanceRacer(r, dt, raceTime, obstacles, jumpPressed, sprinting, speedMul = 1) {
    const events = {
      jumped: false,
      perfect: false,
      landed: false,
      hitObstacle: null,
      spawnedRunDust: false
    };
    if (r.stumble > 0) r.stumble = Math.max(0, r.stumble - dt);
    if (jumpPressed && r.stumble <= 0 && !r.airborne) {
      const sinceLand = raceTime - r.lastLand;
      const isPerfect = sinceLand >= 0 && sinceLand <= PERFECT_WINDOW;
      executeJump(r, isPerfect);
      events.jumped = true;
      events.perfect = isPerfect;
    } else if (jumpPressed && r.airborne) {
      r.earlyJump = 0.16;
    }
    if (r.earlyJump > 0) {
      r.earlyJump = Math.max(0, r.earlyJump - dt);
    }
    const wantSprint = sprinting && r.stamina > 0.5 && r.stumble <= 0;
    if (wantSprint) {
      r.stamina = Math.max(0, r.stamina - 34 * dt);
      r.sprintCd = 0.5;
      r.sprintFx = 0.14;
    } else {
      r.sprintCd = Math.max(0, (r.sprintCd || 0) - dt);
      if (r.sprintCd <= 0) r.stamina = Math.min(100, r.stamina + 25 * dt);
      r.sprintFx = Math.max(0, (r.sprintFx || 0) - dt);
    }
    if (r.staminaGhost > r.stamina) {
      r.staminaGhost = Math.max(r.stamina, r.staminaGhost - 28 * dt);
    } else {
      r.staminaGhost = r.stamina;
    }
    let mult = 1 + r.flow * FLOW_STEP;
    if (wantSprint) mult *= SPRINT_MULT;
    let target = r.base * mult * speedMul;
    if (r.stumble > 0) target *= 0.3;
    r.speed += (target - r.speed) * Math.min(1, dt * (r.stumble > 0 ? 2.2 : 4.4));
    r.x += r.speed * dt;
    if (r.airborne) {
      r.vh -= GRAV * dt;
      r.h += r.vh * dt;
      r.phase += dt * 2.2;
      if (r.h <= 0) {
        r.h = 0;
        events.landed = true;
        const landRes = executeLand(r, raceTime);
        if (landRes.autoHopped) {
          events.jumped = true;
          events.perfect = true;
        }
      }
    } else {
      r.h = 0;
      r.vh = 0;
      if (r.speed > 0.5) {
        r.phase += dt * (4.2 + r.speed * 0.32);
      }
      r.flow = Math.max(0, r.flow - 0.55 * dt);
      r.dustT -= dt;
      if (r.dustT <= 0 && r.speed > 6) {
        r.dustT = 0.16;
        events.spawnedRunDust = true;
      }
    }
    r.squash += (1 - r.squash) * Math.min(1, dt * 8);
    const hit = checkRacerObstacles(r, obstacles);
    if (hit) events.hitObstacle = hit;
    return events;
  }
  function decideAutoPlayer(p, obstacles, raceTime) {
    let jump = false;
    const o = nextObstacleAhead(obstacles, p.x, 110);
    const gap = o ? o.x - p.x : 999;
    if (!p.airborne) {
      if (gap <= Math.max(5.5, p.speed * 0.37)) {
        jump = true;
      } else if (gap > 48) {
        const dtl = raceTime - p.lastLand;
        if (dtl > 0.02 && dtl < 0.12) jump = true;
      }
    }
    const sprint = p.stamina > 40 && gap > 42;
    return { jump, sprint };
  }
  function stepAIRacer(r, playerX, dt, raceTime, obstacles) {
    let jump = false;
    const o = nextObstacleAhead(obstacles, r.x, 90);
    if (!r.airborne) {
      if (o) {
        if (r.aiDecidedFor !== o) {
          r.aiDecidedFor = o;
          r.aiWillJump = r.rng() < 0.55 + r.aiSkill * 0.5;
          r.aiJumpGap = Math.max(4, r.speed * (0.24 + (1 - r.aiSkill) * 0.2)) + (r.rng() - 0.5) * 2.5;
        }
        if (r.aiDecidedFor === o && r.aiWillJump && o.x - r.x <= r.aiJumpGap) {
          jump = true;
        }
      }
      if (!jump && (!o || o.x - r.x > 46)) {
        const dtl = raceTime - r.lastLand;
        if (dtl > 0.02 && dtl < 0.13) {
          if (r.rng() < 0.3 + r.aiSkill * 0.6) jump = true;
        }
      }
    }
    if (o && o.x - r.x < -8 && r.aiDecidedFor === o) {
      r.aiDecidedFor = null;
    }
    const diff = playerX - r.x;
    const mul = 1 + clamp(diff * 26e-4, -0.085, 0.09);
    return advanceRacer(r, dt, raceTime, obstacles, jump, false, mul);
  }
  function computePlaces(racers) {
    const sorted = racers.slice().sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      if (a.finished) return -1;
      if (b.finished) return 1;
      return b.x - a.x;
    });
    for (let i = 0; i < sorted.length; i++) {
      sorted[i].place = i + 1;
    }
  }
  function buildResults(racers, player, raceTime, newRecord) {
    computePlaces(racers);
    const order = racers.slice().sort((a, b) => a.place - b.place);
    let latestClock = raceTime;
    for (let i = 0; i < racers.length; i++) {
      if (racers[i].finished && racers[i].finishTime > latestClock) {
        latestClock = racers[i].finishTime;
      }
    }
    let prevTime = 0;
    const rows = order.map((r, idx) => {
      let time = r.finished ? r.finishTime : latestClock + Math.max(0.15, (RACE_LEN - r.x) / Math.max(14, r.speed));
      if (idx > 0 && time < prevTime + 0.1) {
        time = prevTime + 0.1;
      }
      prevTime = time;
      return {
        name: r.isPlayer ? "\u0422\u042B" : r.name,
        place: r.place,
        time,
        isPlayer: r.isPlayer,
        scarf: r.scarf
      };
    });
    return {
      rows,
      playerPlace: player.place,
      playerTime: player.finishTime || raceTime,
      newRecord
    };
  }

  // src/game/sound.ts
  var SoundEngine = class {
    constructor() {
      this.ac = null;
      this.master = null;
      this.muted = false;
    }
    unlockFromGesture() {
      try {
        if (this.ac) {
          if (this.ac.state === "suspended") {
            this.ac.resume().catch(() => {
            });
          }
          return;
        }
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ac = new AC();
        this.master = this.ac.createGain();
        this.master.gain.value = 0.42;
        this.master.connect(this.ac.destination);
        if (this.ac.state === "suspended") {
          this.ac.resume().catch(() => {
          });
        }
      } catch {
        this.ac = null;
      }
    }
    init() {
      if (this.ac && this.ac.state === "suspended") {
        this.ac.resume().catch(() => {
        });
      }
    }
    setMuted(m) {
      this.muted = m;
    }
    tone(freq, dur, type = "sine", gain = 0.12, slideTo, delay = 0) {
      if (!this.ac || !this.master || this.muted || this.ac.state !== "running") return;
      try {
        const ac = this.ac;
        const t0 = ac.currentTime + delay;
        const osc = ac.createOscillator();
        const g = ac.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, t0);
        if (slideTo) {
          osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
        }
        g.gain.setValueAtTime(1e-4, t0);
        g.gain.exponentialRampToValueAtTime(Math.max(1e-3, gain), t0 + 0.012);
        g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
        osc.connect(g);
        g.connect(this.master);
        osc.start(t0);
        osc.stop(t0 + dur + 0.03);
      } catch {
      }
    }
    noise(dur, freq = 900, gain = 0.18) {
      if (!this.ac || !this.master || this.muted || this.ac.state !== "running") return;
      try {
        const ac = this.ac;
        const len = Math.max(1, Math.floor(ac.sampleRate * dur));
        const buf = ac.createBuffer(1, len, ac.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < len; i++) {
          d[i] = (Math.random() * 2 - 1) * (1 - i / len);
        }
        const src = ac.createBufferSource();
        src.buffer = buf;
        const f = ac.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = freq;
        const g = ac.createGain();
        g.gain.value = gain;
        src.connect(f);
        f.connect(g);
        g.connect(this.master);
        src.start();
      } catch {
      }
    }
    hop() {
      const jitter = 0.94 + Math.random() * 0.12;
      this.tone(195 * jitter, 0.1, "sine", 0.1, 96 * jitter);
      this.noise(0.07, 820, 0.06);
    }
    land() {
      const jitter = 0.93 + Math.random() * 0.14;
      this.noise(0.055, 520 * jitter, 0.05);
    }
    perfect(combo = 1) {
      const k = Math.min(6, combo || 1);
      this.tone(620 + k * 45, 0.13, "triangle", 0.1);
      this.tone(930 + k * 60, 0.16, "sine", 0.075, null, 0.055);
    }
    stumble() {
      this.noise(0.3, 460, 0.26);
      this.tone(150, 0.24, "sawtooth", 0.09, 62);
    }
    count(last) {
      this.tone(last ? 900 : 520, last ? 0.32 : 0.12, "square", 0.07);
    }
    finish() {
      [523, 659, 784, 1046].forEach((f, i) => {
        this.tone(f, 0.34, "triangle", 0.1, null, i * 0.105);
      });
    }
  };
  var Sfx = new SoundEngine();

  // src/game/textures.ts
  var cachedTextures = null;
  function createOffscreen(w, h) {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const ctx = c.getContext("2d");
    return [c, ctx];
  }
  function makeSandTile(baseColor, lightColor, darkColor, rippleSpacing, seed) {
    const w = 256;
    const h = 128;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, w, h);
    ctx.lineWidth = 1.6;
    for (let y = 4; y < h; y += rippleSpacing) {
      ctx.strokeStyle = darkColor;
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      for (let x = 0; x <= w; x += 8) {
        const u = x / w * TAU;
        const dy = Math.sin(u * 2 + y * 0.15) * 2.2 + Math.cos(u + y * 0.08) * 1.2;
        if (x === 0) ctx.moveTo(x, y + dy);
        else ctx.lineTo(x, y + dy);
      }
      ctx.stroke();
      ctx.strokeStyle = lightColor;
      ctx.globalAlpha = 0.28;
      ctx.beginPath();
      for (let x = 0; x <= w; x += 8) {
        const u = x / w * TAU;
        const dy = Math.sin(u * 2 + y * 0.15) * 2.2 + Math.cos(u + y * 0.08) * 1.2 - 1.5;
        if (x === 0) ctx.moveTo(x, y + dy);
        else ctx.lineTo(x, y + dy);
      }
      ctx.stroke();
    }
    for (let i = 0; i < 900; i++) {
      const gx = rnd() * w;
      const gy = rnd() * h;
      const isLight = rnd() > 0.48;
      ctx.fillStyle = isLight ? lightColor : darkColor;
      ctx.globalAlpha = 0.08 + rnd() * 0.16;
      const sz = rnd() > 0.85 ? 2 : 1.2;
      ctx.fillRect(gx, gy, sz, sz);
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeMesaTile(seed) {
    const w = 256;
    const h = 256;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "#d88c5e");
    g.addColorStop(0.35, "#c7774b");
    g.addColorStop(0.7, "#b2623c");
    g.addColorStop(1, "#964e2e");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    const bands = [
      [14, 8, "#f0b684", 0.28],
      [32, 5, "#8c4326", 0.26],
      [54, 12, "#e29b6b", 0.24],
      [82, 6, "#7d391e", 0.3],
      [108, 14, "#eba97a", 0.22],
      [136, 7, "#823c20", 0.28],
      [164, 10, "#df9566", 0.25],
      [194, 6, "#733219", 0.3],
      [222, 12, "#cfa078", 0.2]
    ];
    for (const [by, bh, col, alpha] of bands) {
      ctx.fillStyle = col;
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.moveTo(0, by);
      for (let x = 0; x <= w; x += 16) {
        const u = x / w * TAU;
        ctx.lineTo(x, by + Math.sin(u * 2 + by) * 1.8);
      }
      for (let x = w; x >= 0; x -= 16) {
        const u = x / w * TAU;
        ctx.lineTo(x, by + bh + Math.sin(u * 2 + by) * 1.8);
      }
      ctx.closePath();
      ctx.fill();
    }
    ctx.strokeStyle = "#6b2e16";
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 18; i++) {
      const vx = rnd() * w;
      const vy = rnd() * (h - 40);
      const len = 18 + rnd() * 44;
      ctx.globalAlpha = 0.14 + rnd() * 0.14;
      ctx.beginPath();
      ctx.moveTo(vx, vy);
      ctx.lineTo(vx + (rnd() - 0.5) * 4, vy + len * 0.5);
      ctx.lineTo(vx + (rnd() - 0.5) * 6, vy + len);
      ctx.stroke();
    }
    for (let i = 0; i < 500; i++) {
      ctx.fillStyle = rnd() > 0.5 ? "#ffcaa0" : "#632b15";
      ctx.globalAlpha = 0.08 + rnd() * 0.12;
      ctx.fillRect(rnd() * w, rnd() * h, 1.5, 1.5);
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeTrackTile(seed) {
    const w = 256;
    const h = 224;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "#d8a25e");
    g.addColorStop(0.14, "#e5b472");
    g.addColorStop(0.45, "#dead6b");
    g.addColorStop(0.75, "#c98e4b");
    g.addColorStop(1, "#995f29");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    const rutYs = [36, 66, 98, 130];
    for (const ry of rutYs) {
      ctx.fillStyle = "rgba(255, 242, 210, 0.24)";
      ctx.fillRect(0, ry - 7, w, 12);
      ctx.fillStyle = "rgba(105, 58, 20, 0.20)";
      ctx.fillRect(0, ry + 5, w, 2.5);
    }
    for (let i = 0; i < 1600; i++) {
      const gx = rnd() * w;
      const gy = rnd() * h;
      const r = rnd();
      ctx.fillStyle = r < 0.45 ? "#fff0cf" : r < 0.8 ? "#8c5222" : "#613512";
      ctx.globalAlpha = 0.1 + rnd() * 0.18;
      const rw = 1 + rnd() * 2.2;
      const rh = 1 + rnd() * 1.4;
      ctx.fillRect(gx, gy, rw, rh);
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeWoodTile(seed) {
    const w = 128;
    const h = 128;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    ctx.fillStyle = "#9c6635";
    ctx.fillRect(0, 0, w, h);
    for (let x = 0; x < w; x += 2) {
      const shade = rnd() > 0.5 ? "#b87e47" : "#73461f";
      ctx.fillStyle = shade;
      ctx.globalAlpha = 0.18 + rnd() * 0.2;
      ctx.fillRect(x, 0, 1.5, h);
    }
    ctx.strokeStyle = "#543012";
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 14; i++) {
      const kx = rnd() * w;
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      ctx.moveTo(kx, 0);
      ctx.bezierCurveTo(kx + 5, h * 0.33, kx - 5, h * 0.66, kx, h);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeRockTile(seed) {
    const w = 128;
    const h = 128;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    ctx.fillStyle = "#b08558";
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 700; i++) {
      const rx = rnd() * w;
      const ry = rnd() * h;
      ctx.fillStyle = rnd() > 0.5 ? "#e6c59c" : "#6e4b2a";
      ctx.globalAlpha = 0.14 + rnd() * 0.2;
      const sz = 1 + rnd() * 2.5;
      ctx.fillRect(rx, ry, sz, sz);
    }
    ctx.strokeStyle = "#523418";
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 10; i++) {
      const x0 = rnd() * w;
      const y0 = rnd() * h;
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x0 + 18, y0 + 10);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeCactusTile(seed) {
    const w = 64;
    const h = 64;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    ctx.fillStyle = "#5d8544";
    ctx.fillRect(0, 0, w, h);
    for (let x = 0; x < w; x += 8) {
      ctx.fillStyle = "#78a35c";
      ctx.globalAlpha = 0.35;
      ctx.fillRect(x, 0, 3, h);
      ctx.fillStyle = "#3e5e2c";
      ctx.globalAlpha = 0.35;
      ctx.fillRect(x + 4, 0, 2, h);
    }
    for (let i = 0; i < 180; i++) {
      ctx.fillStyle = rnd() > 0.5 ? "#96bf78" : "#355224";
      ctx.globalAlpha = 0.15;
      ctx.fillRect(rnd() * w, rnd() * h, 1.5, 1.5);
    }
    ctx.globalAlpha = 1;
    return c;
  }
  function makeFurTile(seed) {
    const w = 64;
    const h = 64;
    const [c, ctx] = createOffscreen(w, h);
    const rnd = mulberry32(seed);
    ctx.clearRect(0, 0, w, h);
    ctx.lineWidth = 1.1;
    ctx.lineCap = "round";
    for (let i = 0; i < 220; i++) {
      const fx = rnd() * w;
      const fy = rnd() * h;
      ctx.strokeStyle = rnd() > 0.45 ? "rgba(255, 220, 165, 0.24)" : "rgba(140, 65, 15, 0.20)";
      ctx.beginPath();
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx - 3.5, fy + 1.2);
      ctx.stroke();
    }
    return c;
  }
  function getTextures(ctx) {
    if (cachedTextures) return cachedTextures;
    const sandFarCanvas = makeSandTile("#e6b479", "#ffdfa8", "#b87f44", 18, 101);
    const sandMidCanvas = makeSandTile("#dca264", "#ffd89c", "#a86e34", 14, 202);
    const sandNearCanvas = makeSandTile("#cf9252", "#ffc982", "#945b24", 11, 303);
    const mesaCanvas = makeMesaTile(404);
    const trackCanvas = makeTrackTile(505);
    const woodCanvas = makeWoodTile(606);
    const rockCanvas = makeRockTile(707);
    const cactusCanvas = makeCactusTile(808);
    const furCanvas = makeFurTile(909);
    cachedTextures = {
      sandFar: ctx.createPattern(sandFarCanvas, "repeat"),
      sandMid: ctx.createPattern(sandMidCanvas, "repeat"),
      sandNear: ctx.createPattern(sandNearCanvas, "repeat"),
      mesaStrata: ctx.createPattern(mesaCanvas, "repeat"),
      trackSurface: ctx.createPattern(trackCanvas, "repeat"),
      woodGrain: ctx.createPattern(woodCanvas, "repeat"),
      rockSurface: ctx.createPattern(rockCanvas, "repeat"),
      cactusSkin: ctx.createPattern(cactusCanvas, "repeat"),
      furGrain: ctx.createPattern(furCanvas, "repeat")
    };
    return cachedTextures;
  }

  // src/game/jerboa.ts
  var JERBOA_COLORS = {
    line: "#46260e",
    fur: "#eb9238",
    furDark: "#c96f1e",
    furDeep: "#a65512",
    furLight: "#f8be72",
    furRim: "#ffdf9e",
    cream: "#fce29c",
    creamLight: "#fff1c7",
    creamShade: "#e3be74",
    earIn: "#f49386",
    earInLight: "#ffb3a8",
    earInShade: "#d97366",
    earEdge: "#8c5028",
    earEdgeLight: "#ad6938",
    skin: "#f4929a",
    skinLight: "#ffb5bc",
    skinDark: "#d9747d",
    claw: "#522c12",
    tuft: "#9c5825",
    tuftLight: "#ba6e34",
    tuftDark: "#6b3812",
    nose: "#592e10",
    eyeWhite: "#fffcf2",
    iris: "#8b9b28",
    irisLight: "#b3c441",
    irisDark: "#5b6914",
    pupil: "#1c150c",
    coat: "#f2d7a4",
    coatShade: "#cfb078",
    pants: "#784f2c",
    boot: "#54341a",
    riderSkin: "#eac296",
    strap: "#543418"
  };
  function ell(ctx, x, y, rx, ry, rot = 0) {
    ctx.beginPath();
    ctx.ellipse(x, y, Math.max(0.2, rx), Math.max(0.2, ry), rot, 0, TAU);
  }
  function fillStroke(ctx, fill, stroke, lw = 4) {
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = lw;
      ctx.stroke();
    }
  }
  function limbPath(ctx, pts) {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2;
      const my = (pts[i][1] + pts[i + 1][1]) / 2;
      ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
    }
    const last = pts[pts.length - 1];
    ctx.lineTo(last[0], last[1]);
  }
  function limb(ctx, pts, width, color) {
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    limbPath(ctx, pts);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
  }
  function limbOutlined(ctx, pts, width, color) {
    limb(ctx, pts, width + 6.2, JERBOA_COLORS.line);
    limb(ctx, pts, width, color);
  }
  function pointOnPath(pts, u) {
    let total = 0;
    const segs = [];
    for (let i = 0; i < pts.length - 1; i++) {
      const d = Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
      segs.push(d);
      total += d;
    }
    let target = u * total;
    for (let i = 0; i < segs.length; i++) {
      if (target <= segs[i] || i === segs.length - 1) {
        const k = segs[i] ? clamp(target / segs[i], 0, 1) : 0;
        return [lerp(pts[i][0], pts[i + 1][0], k), lerp(pts[i][1], pts[i + 1][1], k)];
      }
      target -= segs[i];
    }
    const last = pts[pts.length - 1];
    return [last[0], last[1]];
  }
  function strokeTaperSegment(ctx, pts, w0, w1, color) {
    const segs = 10;
    let prev = pts[0];
    ctx.lineCap = "round";
    for (let i = 1; i <= segs; i++) {
      const u = i / segs;
      const p = pointOnPath(pts, u);
      const w = lerp(w0, w1, u);
      limb(ctx, [prev, p], w, color);
      prev = p;
    }
  }
  function bezPoint(p0, p1, p2, p3, t) {
    const u = 1 - t;
    const a = u * u * u;
    const b = 3 * u * u * t;
    const c = 3 * u * t * t;
    const d = t * t * t;
    return [
      a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0],
      a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]
    ];
  }
  function drawTail(ctx, pose) {
    const C = JERBOA_COLORS;
    const { t, air, speed } = pose;
    const wave = Math.sin(t * 7.5) * 5.5 + Math.sin(t * 13.3) * 2.5;
    const lift = air * 14;
    const p0 = [-46, -132];
    const p1 = [-96, -68 + wave * 0.6 - lift * 0.3];
    const p2 = [-164, -64 + wave - lift * 0.7];
    const p3 = [
      -172,
      -220 + wave * 1.2 - lift * 1.1 - clamp(speed * 0.35, 0, 10)
    ];
    ctx.save();
    ctx.lineCap = "round";
    let prev = p0;
    const segs = 18;
    for (let i = 1; i <= segs; i++) {
      const u = i / segs;
      const pt = bezPoint(p0, p1, p2, p3, u);
      const w = lerp(8.2, 2.8, u);
      limb(ctx, [prev, pt], w + 5.2, C.line);
      prev = pt;
    }
    prev = p0;
    for (let j = 1; j <= segs; j++) {
      const u2 = j / segs;
      const pt2 = bezPoint(p0, p1, p2, p3, u2);
      const w2 = lerp(7, 2, u2);
      limb(ctx, [prev, pt2], w2, u2 > 0.65 ? C.skinDark : C.skin);
      prev = pt2;
    }
    prev = p0;
    for (let j = 1; j <= 12; j++) {
      const u2 = j / segs;
      const pt2 = bezPoint(p0, p1, p2, p3, u2);
      const w2 = lerp(2.2, 0.8, u2);
      limb(
        ctx,
        [
          [prev[0] + 1.2, prev[1] - 0.6],
          [pt2[0] + 1.2, pt2[1] - 0.6]
        ],
        w2,
        C.skinLight
      );
      prev = pt2;
    }
    const tip = p3;
    ctx.save();
    ctx.translate(tip[0], tip[1]);
    ctx.rotate(-0.42 + Math.sin(t * 4.2) * 0.07);
    ctx.beginPath();
    ctx.moveTo(0, 12);
    ctx.bezierCurveTo(-12, -8, -14, -36, -6, -56);
    ctx.lineTo(-1, -48);
    ctx.lineTo(6, -68);
    ctx.lineTo(9, -56);
    ctx.lineTo(18, -76);
    ctx.lineTo(20, -62);
    ctx.lineTo(29, -74);
    ctx.bezierCurveTo(28, -50, 24, -36, 17, -28);
    ctx.lineTo(22, -25);
    ctx.bezierCurveTo(14, -12, 8, 2, 0, 12);
    ctx.closePath();
    const tg = ctx.createLinearGradient(0, 12, 24, -74);
    tg.addColorStop(0, C.tuftDark);
    tg.addColorStop(0.45, C.tuft);
    tg.addColorStop(1, C.tuftLight);
    fillStroke(ctx, tg, C.line, 3.2);
    ctx.beginPath();
    ctx.moveTo(2, 2);
    ctx.quadraticCurveTo(6, -28, 16, -58);
    ctx.strokeStyle = "rgba(255, 210, 150, 0.35)";
    ctx.lineWidth = 2.2;
    ctx.stroke();
    ctx.restore();
    ctx.restore();
  }
  function earPath(ctx, bx, by, len, wid, ang) {
    const dx = Math.cos(ang);
    const dy = Math.sin(ang);
    const px = -dy;
    const py = dx;
    const tipX = bx + dx * len;
    const tipY = by + dy * len;
    ctx.beginPath();
    ctx.moveTo(bx - px * wid * 0.38, by - py * wid * 0.38);
    ctx.bezierCurveTo(
      bx + dx * len * 0.12 - px * wid * 0.78,
      by + dy * len * 0.12 - py * wid * 0.78,
      bx + dx * len * 0.62 - px * wid * 0.72,
      by + dy * len * 0.62 - py * wid * 0.72,
      tipX - px * wid * 0.12,
      tipY - py * wid * 0.12
    );
    ctx.quadraticCurveTo(
      tipX + dx * wid * 0.22,
      tipY + dy * wid * 0.22,
      tipX + px * wid * 0.16,
      tipY + py * wid * 0.16
    );
    ctx.bezierCurveTo(
      bx + dx * len * 0.66 + px * wid * 0.68,
      by + dy * len * 0.66 + py * wid * 0.68,
      bx + dx * len * 0.22 + px * wid * 0.6,
      by + dy * len * 0.22 + py * wid * 0.6,
      bx + px * wid * 0.34,
      by + py * wid * 0.34
    );
    ctx.closePath();
  }
  function drawEar(ctx, bx, by, len, wid, ang, far) {
    const C = JERBOA_COLORS;
    const dx = Math.cos(ang);
    const dy = Math.sin(ang);
    earPath(ctx, bx, by, len, wid, ang);
    const outerGrad = ctx.createLinearGradient(bx, by, bx + dx * len, by + dy * len);
    outerGrad.addColorStop(0, far ? "#75411e" : C.earEdgeLight);
    outerGrad.addColorStop(1, far ? "#5e3215" : C.earEdge);
    fillStroke(ctx, outerGrad, C.line, 4.2);
    earPath(ctx, bx + dx * len * 0.05, by + dy * len * 0.05, len * 0.88, wid * 0.78, ang);
    fillStroke(ctx, far ? "#6e3b1b" : "#96572d", C.line, 2);
    earPath(ctx, bx + dx * len * 0.11, by + dy * len * 0.11, len * 0.78, wid * 0.58, ang);
    const inGrad = ctx.createLinearGradient(bx, by, bx + dx * len, by + dy * len);
    inGrad.addColorStop(0, far ? C.earInShade : C.earIn);
    inGrad.addColorStop(0.7, far ? C.earIn : C.earInLight);
    inGrad.addColorStop(1, far ? C.earInShade : C.earIn);
    fillStroke(ctx, inGrad, C.line, 1.8);
  }
  function drawLeg(ctx, hip, knee, ankle, toe, color, far) {
    const C = JERBOA_COLORS;
    const ang = Math.atan2(toe[1] - ankle[1], toe[0] - ankle[0]);
    const spreadAngles = [-0.28, 0, 0.26];
    const toeEnds = spreadAngles.map((da, i) => {
      const a = ang + da;
      const toeLen = i === 1 ? 16 : 12.5;
      return [toe[0] + Math.cos(a) * toeLen, toe[1] + Math.sin(a) * toeLen];
    });
    strokeTaperSegment(ctx, [hip, knee], 21, 14.5, C.line);
    strokeTaperSegment(ctx, [knee, ankle], 14.5, 11.8, C.line);
    strokeTaperSegment(ctx, [ankle, toe], 16.5, 13.5, C.line);
    for (const endPt of toeEnds) {
      strokeTaperSegment(ctx, [toe, endPt], 11.5, 8.5, C.line);
    }
    strokeTaperSegment(ctx, [hip, knee], 15.2, 8.8, color);
    strokeTaperSegment(ctx, [knee, ankle], 8.8, 6.2, color);
    strokeTaperSegment(ctx, [ankle, toe], 11, 8, color);
    for (const endPt of toeEnds) {
      strokeTaperSegment(ctx, [toe, endPt], 6.4, 3.6, color);
    }
    if (!far) {
      strokeTaperSegment(
        ctx,
        [
          [hip[0] + 1.5, hip[1]],
          [knee[0] + 1.5, knee[1]]
        ],
        4.2,
        2.2,
        C.skinLight
      );
      strokeTaperSegment(
        ctx,
        [
          [ankle[0] + 1.2, ankle[1] - 1],
          [toe[0] + 1.2, toe[1] - 1]
        ],
        3.2,
        2,
        C.skinLight
      );
    }
  }
  function legPoints(phase, air, runAmp, far) {
    const s = Math.sin(phase);
    const lift = Math.max(0, Math.sin(phase));
    const hip = far ? [-18, -102] : [-2, -104];
    const kx = (far ? 18 : 28) + s * 19 * runAmp;
    const ky = (far ? -62 : -58) - lift * 8 * runAmp;
    const ax = (far ? 0 : 12) + s * 25 * runAmp;
    const ay = (far ? -22 : -20) - lift * 20 * runAmp;
    const tx = (far ? 56 : 72) + s * 28 * runAmp;
    const ty = (far ? -2 : 1) - Math.max(0, s) * 26 * runAmp;
    const kx2 = far ? 24 : 34;
    const ky2 = -100;
    const ax2 = far ? 42 : 54;
    const ay2 = far ? -70 : -64;
    const tx2 = far ? 60 : 76;
    const ty2 = far ? -50 : -44;
    return {
      hip,
      knee: [lerp(kx, kx2, air), lerp(ky, ky2, air)],
      ankle: [lerp(ax, ax2, air), lerp(ay, ay2, air)],
      toe: [lerp(tx, tx2, air), lerp(ty, ty2, air)]
    };
  }
  function drawFrontPaws(ctx, air, t) {
    const C = JERBOA_COLORS;
    const w = Math.sin(t * 6) * 1.6;
    const defs = [
      { sh: [32, -158], hd: [50, -146 + w], rot: 0.85, sc: 0.92, far: true },
      { sh: [24, -156], hd: [40, -144 - w * 0.6], rot: 0.72, sc: 1, far: false }
    ];
    for (const d of defs) {
      const sh = [d.sh[0], d.sh[1] - air * 6];
      const hd = [d.hd[0], d.hd[1] - air * 8];
      const pColor = d.far ? C.skinDark : C.skin;
      ctx.save();
      limb(ctx, [sh, hd], 9.5 * d.sc, C.line);
      limb(ctx, [sh, hd], 5.8 * d.sc, pColor);
      ctx.translate(hd[0], hd[1]);
      ctx.rotate(d.rot);
      ell(ctx, 0, 0, 5 * d.sc, 6.8 * d.sc, 0);
      fillStroke(ctx, pColor, C.line, 2.4);
      ctx.strokeStyle = C.line;
      ctx.lineWidth = 1.5;
      for (let f = -1; f <= 1; f++) {
        ctx.beginPath();
        ctx.moveTo(2.6, f * 2.2);
        ctx.quadraticCurveTo(6.6, f * 2.6, 8.4, f * 3.3);
        ctx.stroke();
      }
      ctx.restore();
    }
  }
  function drawRider(ctx, o, pose) {
    const C = JERBOA_COLORS;
    const { t, air, phase, speed } = pose;
    const scarf = o.scarf || "#28b5a8";
    const goggle = o.goggle || scarf;
    const coatColor = o.coatColor || C.coat;
    const bob = Math.sin(phase * 2) * 1.8;
    const lean = -0.14 - Math.min(0.2, speed * 6e-3) - air * 0.12;
    ctx.save();
    ctx.translate(0, bob);
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(-22, -190, 22, 9, -0.18, 0, TAU);
    fillStroke(ctx, "#8c4227", C.line, 2.8);
    ctx.restore();
    limbOutlined(
      ctx,
      [
        [-30, -196],
        [-12, -184],
        [4, -176]
      ],
      9,
      C.pants
    );
    ell(ctx, 4, -176, 8.4, 6, 0.15);
    fillStroke(ctx, C.boot, C.line, 3);
    ctx.save();
    ctx.translate(-28, -224);
    ctx.rotate(lean);
    ell(ctx, 0, 0, 16.5, 24, 0);
    const cg = ctx.createLinearGradient(-16, -24, 16, 24);
    cg.addColorStop(0, "#fff0c9");
    cg.addColorStop(0.5, coatColor);
    cg.addColorStop(1, C.coatShade);
    fillStroke(ctx, cg, C.line, 3.8);
    ctx.beginPath();
    ctx.moveTo(-15, 8);
    ctx.quadraticCurveTo(0, 12, 15, 7);
    ctx.strokeStyle = "#5c3618";
    ctx.lineWidth = 4.5;
    ctx.stroke();
    ctx.restore();
    limbOutlined(
      ctx,
      [
        [-24, -196],
        [2, -190],
        [18, -182]
      ],
      10.2,
      C.pants
    );
    ell(ctx, 18, -181, 9.2, 6.5, 0.1);
    fillStroke(ctx, C.boot, C.line, 3);
    limbOutlined(
      ctx,
      [
        [-12, -238],
        [8, -230],
        [26, -222]
      ],
      8.2,
      coatColor
    );
    ell(ctx, 27, -222, 5.8, 5.2, 0);
    fillStroke(ctx, C.riderSkin, C.line, 2.4);
    ctx.save();
    ctx.translate(-20, -254);
    ctx.rotate(0.08);
    ell(ctx, 0, 0, 14, 14.4, 0);
    fillStroke(ctx, C.riderSkin, C.line, 3.2);
    ctx.beginPath();
    ctx.arc(0, -1, 14.4, Math.PI * 0.95, Math.PI * 2.08);
    ctx.closePath();
    const hg = ctx.createLinearGradient(-14, -15, 14, 2);
    hg.addColorStop(0, "#9e6234");
    hg.addColorStop(1, "#6b3e1c");
    fillStroke(ctx, hg, C.line, 2.6);
    ctx.strokeStyle = C.strap;
    ctx.lineWidth = 4.4;
    ctx.beginPath();
    ctx.moveTo(-13, -4);
    ctx.quadraticCurveTo(0, -8, 13, -3.5);
    ctx.stroke();
    ell(ctx, 6.8, -2, 7.4, 6, -0.1);
    fillStroke(ctx, goggle, C.line, 2.6);
    ctx.globalAlpha = 0.9;
    ell(ctx, 4.8, -4.2, 2.5, 1.7, -0.3);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.restore();
    const flap = Math.sin(t * 9.5) * 5.5 + Math.sin(t * 14.5) * 2.8 + air * 6.5 + speed * 0.16;
    ctx.save();
    ctx.translate(-30, -241);
    ctx.beginPath();
    ctx.moveTo(0, -5);
    ctx.bezierCurveTo(-18, -11 - flap * 0.4, -44, -2 + flap, -68, -15 + flap);
    ctx.bezierCurveTo(-52, 5 + flap * 0.7, -24, 13 + flap * 0.3, 0, 6);
    ctx.closePath();
    fillStroke(ctx, scarf, C.line, 3.2);
    ctx.globalAlpha = 0.45;
    ctx.beginPath();
    ctx.moveTo(-6, -2);
    ctx.bezierCurveTo(-22, -4, -38, 0, -56, -6 + flap * 0.65);
    ctx.strokeStyle = "#fff5d6";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.restore();
    ctx.strokeStyle = "#633918";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(26, -221);
    ctx.quadraticCurveTo(64, -206, 102, -188);
    ctx.stroke();
    ctx.restore();
  }
  function drawJerboa(ctx, o) {
    const C = JERBOA_COLORS;
    const textures = getTextures(ctx);
    const rawPose = o.pose || {};
    const pose = {
      t: rawPose.t || 0,
      phase: rawPose.phase || 0,
      air: clamp(rawPose.air || 0, 0, 1),
      vy: rawPose.vy || 0,
      speed: rawPose.speed || 0,
      stumble: rawPose.stumble || 0,
      squash: rawPose.squash == null ? 1 : rawPose.squash,
      lean: rawPose.lean || 0
    };
    const { t, phase, air, vy, speed, stumble, squash } = pose;
    const furBase = o.furTint || C.fur;
    const lean = (pose.lean || 0) + 0.03 + Math.min(0.14, speed * 45e-4) + air * 0.06 + stumble * 0.6;
    const runAmp = clamp(speed / 12, 0, 1) * (1 - air);
    const bob = -Math.abs(Math.sin(phase)) * 4.5 * runAmp;
    ctx.save();
    ctx.translate(o.x, o.y + bob);
    ctx.scale(o.scale || 1, o.scale || 1);
    ctx.rotate(lean);
    ctx.scale(1 + (1 - squash) * 0.5, squash);
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    const earFlop = clamp(-vy * 32e-5, -0.16, 0.24) + Math.sin(t * 2.5) * 0.02;
    const earLen = 116;
    const earWid = 58;
    const nearEarAng = -1.86 + earFlop;
    const farEarAng = -2.07 + earFlop * 1.15;
    drawEar(ctx, 30, -228, earLen * 0.95, earWid * 0.93, farEarAng, true);
    drawTail(ctx, pose);
    const farLeg = legPoints(phase + Math.PI, air, runAmp, true);
    drawLeg(ctx, farLeg.hip, farLeg.knee, farLeg.ankle, farLeg.toe, C.skinDark, true);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(28, -182);
    ctx.bezierCurveTo(2, -196, -28, -196, -44, -182);
    ctx.lineTo(-39, -179);
    ctx.lineTo(-54, -166);
    ctx.lineTo(-48, -162);
    ctx.lineTo(-59, -145);
    ctx.lineTo(-53, -142);
    ctx.bezierCurveTo(-58, -124, -52, -108, -40, -98);
    ctx.lineTo(-34, -93);
    ctx.lineTo(-26, -98);
    ctx.lineTo(-18, -92);
    ctx.bezierCurveTo(6, -88, 34, -98, 44, -124);
    ctx.bezierCurveTo(52, -148, 46, -172, 28, -182);
    ctx.closePath();
    const bodyGrad = ctx.createRadialGradient(-8, -158, 12, -6, -142, 68);
    bodyGrad.addColorStop(0, C.furLight);
    bodyGrad.addColorStop(0.55, furBase);
    bodyGrad.addColorStop(1, C.furDark);
    fillStroke(ctx, bodyGrad, C.line, 4.8);
    if (textures.furGrain) {
      ctx.save();
      ctx.clip();
      ctx.fillStyle = textures.furGrain;
      ctx.fillRect(-70, -210, 130, 130);
      ell(ctx, -20, -168, 28, 18, -0.45);
      ctx.fillStyle = "rgba(255, 226, 168, 0.45)";
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
    ell(ctx, 22, -150, 32, 36, -0.05);
    fillStroke(ctx, furBase, null, 0);
    ell(ctx, 16, -118, 33, 30, -0.12);
    const bellyGrad = ctx.createLinearGradient(16, -148, 16, -90);
    bellyGrad.addColorStop(0, C.creamLight);
    bellyGrad.addColorStop(0.65, C.cream);
    bellyGrad.addColorStop(1, C.creamShade);
    fillStroke(ctx, bellyGrad, null, 0);
    ctx.beginPath();
    ctx.arc(34, -128, 10, -0.5, 2.4);
    ctx.arc(42, -136, 7.5, -0.3, 2.2);
    ctx.fillStyle = C.cream;
    ctx.fill();
    const nearLeg = legPoints(phase, air, runAmp, false);
    drawLeg(ctx, nearLeg.hip, nearLeg.knee, nearLeg.ankle, nearLeg.toe, C.skin, false);
    ell(ctx, -2, -110, 16, 15, 0.1);
    fillStroke(ctx, furBase, null, 0);
    drawFrontPaws(ctx, air, t);
    ctx.save();
    ctx.globalAlpha = 0.22;
    ell(ctx, 34, -190, 22, 26, 0.25);
    ctx.fillStyle = C.furDark;
    ctx.fill();
    ctx.restore();
    drawEar(ctx, 44, -225, earLen, earWid, nearEarAng, false);
    ell(ctx, 52, -198, 38, 36, 0.1);
    const headGrad = ctx.createRadialGradient(46, -210, 8, 52, -198, 42);
    headGrad.addColorStop(0, C.furLight);
    headGrad.addColorStop(0.65, furBase);
    headGrad.addColorStop(1, C.furDark);
    fillStroke(ctx, headGrad, C.line, 4.8);
    ctx.beginPath();
    ctx.moveTo(58, -224);
    ctx.quadraticCurveTo(112, -216, 128, -192);
    ctx.quadraticCurveTo(130, -180, 112, -175);
    ctx.quadraticCurveTo(84, -173, 66, -185);
    ctx.closePath();
    fillStroke(ctx, furBase, C.line, 4.5);
    ell(ctx, 64, -198, 22, 22, 0.1);
    fillStroke(ctx, furBase, null, 0);
    ell(ctx, 73, -211, 18.5, 19.5, 0.08);
    fillStroke(ctx, C.cream, null, 0);
    ell(ctx, 96, -187, 24, 15.5, 0.18);
    fillStroke(ctx, C.cream, null, 0);
    ell(ctx, 66, -191, 16, 14, 0.1);
    fillStroke(ctx, C.cream, null, 0);
    ell(ctx, 115, -183, 11.5, 8.5, 0.18);
    fillStroke(ctx, C.creamLight, null, 0);
    ctx.save();
    ctx.translate(125, -186);
    ctx.rotate(0.2);
    ell(ctx, 0, 0, 8.6, 6.6, 0);
    fillStroke(ctx, C.nose, C.line, 2.4);
    ctx.globalAlpha = 0.55;
    ell(ctx, -2.2, -2.2, 3, 1.9, -0.3);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = C.line;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(112, -175);
    ctx.quadraticCurveTo(96, -172, 82, -184);
    ctx.stroke();
    ell(ctx, 74, -212, 14.8, 15.6, 0.05);
    fillStroke(ctx, C.eyeWhite, C.line, 3);
    ell(ctx, 78, -211, 9, 9.8, 0);
    const ig = ctx.createLinearGradient(74, -220, 82, -202);
    ig.addColorStop(0, C.irisLight);
    ig.addColorStop(1, C.irisDark);
    ctx.fillStyle = ig;
    ctx.fill();
    ctx.strokeStyle = C.irisDark;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ell(ctx, 79, -210.5, 4.5, 5.2, 0);
    ctx.fillStyle = C.pupil;
    ctx.fill();
    ctx.globalAlpha = 0.95;
    ell(ctx, 75, -217, 3, 2.3, -0.4);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ell(ctx, 81, -207, 1.4, 1.2, 0);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = C.line;
    ctx.lineWidth = 3.4;
    ctx.beginPath();
    ctx.moveTo(60, -223);
    ctx.quadraticCurveTo(73, -230, 88, -224);
    ctx.stroke();
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(62, -237);
    ctx.quadraticCurveTo(75, -244, 89, -237);
    ctx.stroke();
    ctx.save();
    ctx.globalAlpha = 0.38;
    ell(ctx, 52, -190, 7, 4.2, -0.35);
    ctx.fillStyle = C.earIn;
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = 0.52;
    ctx.strokeStyle = C.line;
    ctx.lineWidth = 1.4;
    const whisk = [
      [119, -178, 160, -192],
      [121, -177, 164, -177],
      [119, -175, 156, -161]
    ];
    for (let w = 0; w < whisk.length; w++) {
      const a = whisk[w];
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.quadraticCurveTo((a[0] + a[2]) / 2, (a[1] + a[3]) / 2 - 4, a[2], a[3]);
      ctx.stroke();
    }
    ctx.restore();
    if (o.showRider !== false) {
      drawRider(ctx, o, pose);
    }
    ctx.restore();
  }

  // src/game/renderer.ts
  var FONT_DISPLAY = '"Rubik", "Trebuchet MS", sans-serif';
  function rr(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w * 0.5, h * 0.5);
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }
  function txt(ctx, s, x, y, size, color = "#fff3d8", align = "left", weight = "700", alpha) {
    ctx.save();
    ctx.font = `${weight} ${size}px ${FONT_DISPLAY}`;
    ctx.textAlign = align;
    ctx.textBaseline = "alphabetic";
    if (alpha != null) ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.fillText(s, x, y);
    ctx.restore();
  }
  function txtOut(ctx, s, x, y, size, color = "#fff3d8", align = "left", weight = "800", lineW, alpha) {
    ctx.save();
    ctx.font = `${weight} ${size}px ${FONT_DISPLAY}`;
    ctx.textAlign = align;
    ctx.textBaseline = "alphabetic";
    if (alpha != null) ctx.globalAlpha = alpha;
    ctx.lineJoin = "round";
    ctx.lineWidth = lineW || Math.max(4, size * 0.15);
    ctx.strokeStyle = "rgba(46, 22, 8, 0.92)";
    ctx.strokeText(s, x, y);
    ctx.fillStyle = color;
    ctx.fillText(s, x, y);
    ctx.restore();
  }
  function drawSky(ctx, camPx, t) {
    const g = ctx.createLinearGradient(0, 0, 0, HORIZON_Y);
    g.addColorStop(0, "#dc7b3b");
    g.addColorStop(0.26, "#ee9f54");
    g.addColorStop(0.54, "#f8c57c");
    g.addColorStop(0.82, "#fde1ab");
    g.addColorStop(1, "#fff3d6");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, HORIZON_Y + 4);
    const sunX = 1015 - clamp(camPx * 4e-3, 0, 60);
    const sunY = 236;
    const glow = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 300);
    glow.addColorStop(0, "rgba(255, 250, 220, 0.95)");
    glow.addColorStop(0.25, "rgba(255, 226, 156, 0.50)");
    glow.addColorStop(0.6, "rgba(255, 196, 112, 0.18)");
    glow.addColorStop(1, "rgba(255, 180, 100, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, HORIZON_Y);
    const sunGrad = ctx.createLinearGradient(0, sunY - 66, 0, sunY + 66);
    sunGrad.addColorStop(0, "#fffef0");
    sunGrad.addColorStop(1, "#ffd27d");
    ctx.beginPath();
    ctx.arc(sunX, sunY, 64, 0, TAU);
    ctx.fillStyle = sunGrad;
    ctx.fill();
    const clouds = [
      [180, 104, 1.05],
      [540, 74, 0.76],
      [870, 136, 0.9],
      [1170, 68, 0.64]
    ];
    for (let i = 0; i < clouds.length; i++) {
      const c = clouds[i];
      const cx = ((c[0] - camPx * 0.025 + t * 4) % (W + 420) + W + 420) % (W + 420) - 120;
      const cy = c[1];
      const sc = c[2];
      ctx.save();
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = "#e59858";
      ctx.beginPath();
      ctx.ellipse(cx, cy + 5 * sc, 92 * sc, 16 * sc, 0, 0, TAU);
      ctx.ellipse(cx + 52 * sc, cy - 4 * sc, 54 * sc, 14 * sc, 0, 0, TAU);
      ctx.ellipse(cx - 50 * sc, cy + 8 * sc, 46 * sc, 12 * sc, 0, 0, TAU);
      ctx.fill();
      ctx.globalAlpha = 0.55;
      ctx.fillStyle = "#fff6df";
      ctx.beginPath();
      ctx.ellipse(cx, cy, 90 * sc, 17 * sc, 0, 0, TAU);
      ctx.ellipse(cx + 54 * sc, cy - 9 * sc, 54 * sc, 15 * sc, 0, 0, TAU);
      ctx.ellipse(cx - 52 * sc, cy + 4 * sc, 46 * sc, 12 * sc, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    ctx.save();
    ctx.strokeStyle = "rgba(88, 48, 22, 0.48)";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    const birds = [
      [0.88, 134],
      [0.95, 152],
      [1.02, 126],
      [0.42, 108]
    ];
    for (let b = 0; b < birds.length; b++) {
      const bx = ((birds[b][0] * 900 + t * 9 - camPx * 0.02) % (W + 300) + W + 300) % (W + 300) - 150;
      const by = birds[b][1] + Math.sin(t * 2.2 + b) * 4.5;
      const wing = Math.sin(t * 5.5 + b * 1.4) * 3.5;
      ctx.beginPath();
      ctx.moveTo(bx - 9, by + wing * 0.5);
      ctx.quadraticCurveTo(bx - 4, by - 5 - wing, bx, by);
      ctx.quadraticCurveTo(bx + 4, by - 5 - wing, bx + 9, by + wing * 0.5);
      ctx.stroke();
    }
    ctx.restore();
  }
  function drawMesas(ctx, camPx) {
    const textures = getTextures(ctx);
    const shift = camPx * 0.055;
    ctx.save();
    for (let i = -1; i < 7; i++) {
      const idx = i + Math.floor(shift / 330);
      const bx = i * 330 - (shift % 330 + 330) % 330 - 60;
      const h = 88 + Math.abs(idx * 53) % 5 * 22;
      const w = 160 + Math.abs(idx * 37) % 4 * 40;
      const base = HORIZON_Y - 4;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(bx, base);
      ctx.lineTo(bx + w * 0.12, base - h * 0.52);
      ctx.lineTo(bx + w * 0.2, base - h * 0.96);
      ctx.lineTo(bx + w * 0.25, base - h);
      ctx.lineTo(bx + w * 0.72, base - h);
      ctx.lineTo(bx + w * 0.78, base - h * 0.92);
      ctx.lineTo(bx + w * 0.86, base - h * 0.48);
      ctx.lineTo(bx + w, base);
      ctx.closePath();
      ctx.globalAlpha = idx % 2 === 0 ? 0.68 : 0.56;
      if (textures.mesaStrata) {
        ctx.save();
        ctx.translate(bx, base - h);
        ctx.fillStyle = textures.mesaStrata;
        ctx.fill();
        ctx.restore();
      } else {
        ctx.fillStyle = "#c87c52";
        ctx.fill();
      }
      const faceGrad = ctx.createLinearGradient(bx, base - h, bx + w, base);
      faceGrad.addColorStop(0, "rgba(95, 42, 20, 0.34)");
      faceGrad.addColorStop(0.55, "rgba(210, 125, 75, 0.08)");
      faceGrad.addColorStop(1, "rgba(255, 222, 165, 0.35)");
      ctx.fillStyle = faceGrad;
      ctx.fill();
      ctx.strokeStyle = "rgba(255, 232, 185, 0.55)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(bx + w * 0.22, base - h);
      ctx.lineTo(bx + w * 0.74, base - h);
      ctx.lineTo(bx + w * 0.86, base - h * 0.48);
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }
  function drawDuneLayer(ctx, camPx, par, baseColor, pattern, amp, baseY, freq, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    const shift = camPx * par;
    ctx.beginPath();
    ctx.moveTo(0, HORIZON_Y + 4);
    for (let x = 0; x <= W; x += 10) {
      const wx = x + shift;
      const y = baseY + Math.sin(wx * freq) * amp + Math.sin(wx * freq * 0.47 + 2.1) * amp * 0.7;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(W, HORIZON_Y + 4);
    ctx.closePath();
    ctx.fillStyle = baseColor;
    ctx.fill();
    if (pattern) {
      ctx.save();
      ctx.clip();
      ctx.translate(-(shift % 256), 0);
      ctx.fillStyle = pattern;
      ctx.fillRect(-256, baseY - amp * 2, W + 512, HORIZON_Y - baseY + amp * 2 + 20);
      ctx.restore();
    }
    ctx.beginPath();
    for (let x = 0; x <= W; x += 10) {
      const wx = x + shift;
      const y = baseY + Math.sin(wx * freq) * amp + Math.sin(wx * freq * 0.47 + 2.1) * amp * 0.7;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = "rgba(255, 236, 188, 0.55)";
    ctx.lineWidth = 2.4;
    ctx.stroke();
    ctx.restore();
  }
  function drawFarCacti(ctx, camPx) {
    const spacing = 210;
    const shift = camPx * 0.36;
    const off = (shift % spacing + spacing) % spacing;
    const idx0 = Math.floor(shift / spacing);
    ctx.save();
    ctx.globalAlpha = 0.42;
    for (let i = -1; i < W / spacing + 2; i++) {
      const idx = i + idx0;
      const hv = hash01(idx * 3.71);
      if (hv < 0.38) continue;
      const bx = i * spacing - off + (hv - 0.5) * 70;
      const s = 0.38 + hash01(idx * 1.7) * 0.22;
      const h = 148 * s;
      const base = HORIZON_Y - 4;
      ctx.fillStyle = "#7e6f42";
      rr(ctx, bx - 5.5 * s, base - h, 11 * s, h, 5.5 * s);
      ctx.fill();
      rr(ctx, bx - 24 * s, base - h * 0.7, 8.5 * s, 25 * s, 4 * s);
      ctx.fill();
      rr(ctx, bx - 24 * s, base - h * 0.7 + 18 * s, 16 * s, 7.5 * s, 3.5 * s);
      ctx.fill();
      rr(ctx, bx + 16 * s, base - h * 0.84, 8.5 * s, 21 * s, 4 * s);
      ctx.fill();
      rr(ctx, bx + 10 * s, base - h * 0.84 + 15 * s, 14 * s, 7.5 * s, 3.5 * s);
      ctx.fill();
    }
    ctx.restore();
  }
  function drawGround(ctx, camX) {
    const textures = getTextures(ctx);
    const camPx = camX * PPM;
    const g = ctx.createLinearGradient(0, HORIZON_Y, 0, H);
    g.addColorStop(0, "#d8a25e");
    g.addColorStop(0.2, "#e4b26e");
    g.addColorStop(0.55, "#d19854");
    g.addColorStop(1, "#9b612b");
    ctx.fillStyle = g;
    ctx.fillRect(0, HORIZON_Y, W, H - HORIZON_Y);
    if (textures.trackSurface) {
      ctx.save();
      ctx.translate(-((camPx % 256 + 256) % 256), HORIZON_Y);
      ctx.fillStyle = textures.trackSurface;
      ctx.fillRect(-256, 0, W + 512, H - HORIZON_Y);
      ctx.restore();
    }
    ctx.save();
    const dividerYs = [531, 563, 594, 626, 658];
    for (let i = 0; i < dividerYs.length; i++) {
      const dy = dividerYs[i];
      const isOuterEdge = i === 0 || i === dividerYs.length - 1;
      ctx.strokeStyle = isOuterEdge ? "rgba(98, 52, 18, 0.45)" : "rgba(255, 240, 204, 0.28)";
      ctx.lineWidth = isOuterEdge ? 3 : 2;
      if (!isOuterEdge) {
        ctx.setLineDash([24, 18]);
        ctx.lineDashOffset = camPx * 0.9 % 42;
      } else {
        ctx.setLineDash([]);
      }
      ctx.beginPath();
      ctx.moveTo(0, dy);
      ctx.lineTo(W, dy);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.restore();
    ctx.strokeStyle = "rgba(110, 62, 24, 0.48)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, HORIZON_Y + 1);
    ctx.lineTo(W, HORIZON_Y + 1);
    ctx.stroke();
    const fromM = Math.floor(camX / 2) * 2 - 6;
    for (let m = fromM; m < camX + W / PPM + 8; m += 2) {
      const sx = START_X + (m - camX) * PPM;
      if (sx < -40 || sx > W + 40) continue;
      const h1 = hash01(m * 12.9);
      if (h1 < 0.48) continue;
      const onUpperShoulder = hash01(m * 5.7) < 0.35;
      const py = onUpperShoulder ? HORIZON_Y + 6 + hash01(m * 3.3) * 18 : GROUND + 16 + hash01(m * 3.3) * 56;
      const s = 2 + hash01(m * 7.1) * 4;
      ctx.save();
      ctx.fillStyle = "rgba(68, 36, 12, 0.32)";
      ctx.beginPath();
      ctx.ellipse(sx + 1.2, py + 1.4, s * 1.05, s * 0.65, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = h1 > 0.75 ? "#8e582b" : "#a86f3c";
      ctx.beginPath();
      ctx.ellipse(sx, py, s, s * 0.62, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(255, 232, 190, 0.45)";
      ctx.beginPath();
      ctx.ellipse(sx - s * 0.2, py - s * 0.18, s * 0.55, s * 0.3, -0.2, 0, TAU);
      ctx.fill();
      ctx.restore();
      if (h1 > 0.9) {
        ctx.save();
        ctx.strokeStyle = "#7c642e";
        ctx.lineWidth = 1.6;
        ctx.lineCap = "round";
        for (let t = -1; t <= 1; t++) {
          ctx.beginPath();
          ctx.moveTo(sx, py + 2);
          ctx.quadraticCurveTo(sx + t * 6, py - 5, sx + t * 9, py - 11);
          ctx.stroke();
        }
        ctx.restore();
      }
    }
  }
  function drawArch(ctx, worldX, label, color, camX, t) {
    const sx = START_X + (worldX - camX) * PPM;
    if (sx < -260 || sx > W + 260) return;
    const textures = getTextures(ctx);
    const farPostX = sx - 96;
    const farPostY = HORIZON_Y + 18;
    const nearPostX = sx + 96;
    const nearPostY = GROUND + 14;
    const topY = HORIZON_Y - 178;
    const postW = 18;
    ctx.save();
    ctx.save();
    const rows = 8;
    const stripTop = HORIZON_Y + 18;
    const stripBot = GROUND + 14;
    const rowH = (stripBot - stripTop) / rows;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < 2; c++) {
        ctx.fillStyle = (r + c) % 2 === 0 ? "rgba(255, 248, 225, 0.78)" : "rgba(52, 26, 10, 0.65)";
        ctx.fillRect(sx - 10 + c * 10, stripTop + r * rowH, 10, rowH + 0.5);
      }
    }
    ctx.restore();
    const posts = [
      { px: farPostX, py: farPostY },
      { px: nearPostX, py: nearPostY }
    ];
    for (const { px, py } of posts) {
      const postH = py - topY;
      ctx.fillStyle = "rgba(58, 30, 10, 0.28)";
      ctx.beginPath();
      ctx.ellipse(px, py + 3, 22, 6, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#9e7348";
      rr(ctx, px - postW * 0.85, py - 22, postW * 1.7, 24, 5);
      ctx.fill();
      ctx.strokeStyle = "#4a2810";
      ctx.lineWidth = 2.2;
      ctx.stroke();
      rr(ctx, px - postW / 2, topY, postW, postH - 18, 6);
      if (textures.woodGrain) {
        ctx.fillStyle = textures.woodGrain;
        ctx.fill();
      } else {
        ctx.fillStyle = "#9c6635";
        ctx.fill();
      }
      ctx.strokeStyle = "#4a260e";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.fillStyle = "#e2be82";
      for (let r = 0; r < 3; r++) {
        rr(ctx, px - postW * 0.62, topY + 14 + r * 6, postW * 1.24, 4.5, 2);
        ctx.fill();
        ctx.stroke();
      }
    }
    const span = nearPostX - farPostX;
    for (let s = -1; s <= 1; s += 2) {
      const lx = sx + s * (span * 0.5 - 18);
      const ly = topY + 66 + Math.sin(t * 3.5 + s) * 1.5;
      const glow = ctx.createRadialGradient(lx, ly, 2, lx, ly, 24);
      glow.addColorStop(0, "rgba(255, 230, 140, 0.85)");
      glow.addColorStop(1, "rgba(255, 180, 60, 0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(lx, ly, 24, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ffdf78";
      rr(ctx, lx - 5.5, ly - 7, 11, 14, 4);
      ctx.fill();
      ctx.strokeStyle = "#4a260e";
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    const wave = Math.sin(t * 4.2) * 3;
    ctx.beginPath();
    ctx.moveTo(farPostX - 8, topY + 2);
    ctx.quadraticCurveTo(sx, topY + 22 + wave, nearPostX + 8, topY + 2);
    ctx.lineTo(nearPostX + 8, topY + 58);
    ctx.quadraticCurveTo(sx, topY + 78 + wave, farPostX - 8, topY + 58);
    ctx.closePath();
    const banGrad = ctx.createLinearGradient(0, topY, 0, topY + 78);
    banGrad.addColorStop(0, color);
    banGrad.addColorStop(1, color === "#e0534b" ? "#b0342d" : "#286b54");
    ctx.fillStyle = banGrad;
    ctx.fill();
    ctx.strokeStyle = "#46240c";
    ctx.lineWidth = 3.2;
    ctx.stroke();
    txtOut(ctx, label, sx, topY + 42 + wave * 0.4, 25, "#fff8e6", "center", "800", 6);
    ctx.restore();
  }
  function drawDistancePosts(ctx, camX) {
    const textures = getTextures(ctx);
    const postBaseY = HORIZON_Y + 12;
    for (let d = 150; d < RACE_LEN; d += 150) {
      const sx = START_X + (d - camX) * PPM;
      if (sx < -80 || sx > W + 80) continue;
      ctx.save();
      ctx.fillStyle = "rgba(60, 30, 10, 0.25)";
      ctx.beginPath();
      ctx.ellipse(sx + 3, postBaseY + 2, 12, 4, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = textures.woodGrain || "#8a5a30";
      rr(ctx, sx, postBaseY - 54, 7, 54, 3);
      ctx.fill();
      ctx.strokeStyle = "#4a260e";
      ctx.lineWidth = 2;
      ctx.stroke();
      const sg = ctx.createLinearGradient(0, postBaseY - 68, 0, postBaseY - 40);
      sg.addColorStop(0, "#fff0c9");
      sg.addColorStop(1, "#e4c288");
      ctx.fillStyle = sg;
      rr(ctx, sx - 22, postBaseY - 68, 52, 24, 6);
      ctx.fill();
      ctx.strokeStyle = "#5a3214";
      ctx.lineWidth = 2.2;
      ctx.stroke();
      txt(ctx, `${d} \u043C`, sx + 4, postBaseY - 51, 13, "#4a260e", "center", "800");
      ctx.restore();
    }
  }
  function drawSingleObstacleAt(ctx, o, sx, baseY, scale = 1) {
    const textures = getTextures(ctx);
    const base = baseY + 2;
    ctx.save();
    ctx.translate(sx, base);
    ctx.scale(scale, scale);
    ctx.fillStyle = "rgba(68, 36, 14, 0.28)";
    ctx.beginPath();
    ctx.ellipse(0, 4, o.w * PPM * 0.66, 9, 0, 0, TAU);
    ctx.fill();
    if (o.type === "rock") {
      const w = o.w * PPM * 0.94;
      const h = o.h;
      ctx.beginPath();
      ctx.moveTo(-w * 0.52, 0);
      ctx.lineTo(-w * 0.44, -h * 0.58);
      ctx.lineTo(-w * 0.18, -h * 0.94);
      ctx.lineTo(w * 0.18, -h);
      ctx.lineTo(w * 0.46, -h * 0.62);
      ctx.lineTo(w * 0.54, 0);
      ctx.closePath();
      if (textures.rockSurface) {
        ctx.save();
        ctx.clip();
        ctx.translate(-w, -h);
        ctx.fillStyle = textures.rockSurface;
        ctx.fillRect(0, 0, w * 2, h + 10);
        ctx.restore();
      }
      const rg = ctx.createLinearGradient(-w / 2, -h, w / 2, 0);
      rg.addColorStop(0, "rgba(255, 230, 185, 0.48)");
      rg.addColorStop(0.5, "rgba(180, 130, 80, 0.25)");
      rg.addColorStop(1, "rgba(95, 58, 28, 0.55)");
      ctx.fillStyle = rg;
      ctx.fill();
      ctx.strokeStyle = "#4e3016";
      ctx.lineWidth = 3.2;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-w * 0.18, -h * 0.94);
      ctx.lineTo(-w * 0.04, -h * 0.46);
      ctx.lineTo(w * 0.46, -h * 0.62);
      ctx.strokeStyle = "rgba(255, 240, 205, 0.55)";
      ctx.lineWidth = 2;
      ctx.stroke();
    } else if (o.type === "cactus") {
      const cw = 22;
      const h2 = o.h;
      const armY = -h2 * 0.58;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.strokeStyle = "#365226";
      ctx.lineWidth = 17;
      ctx.beginPath();
      ctx.moveTo(-cw * 0.4, armY);
      ctx.quadraticCurveTo(-cw * 0.5 - 24, armY, -cw * 0.5 - 24, armY - 32);
      ctx.moveTo(cw * 0.4, armY - 14);
      ctx.quadraticCurveTo(cw * 0.5 + 22, armY - 14, cw * 0.5 + 22, armY - 44);
      ctx.stroke();
      ctx.strokeStyle = "#68914c";
      ctx.lineWidth = 11.5;
      ctx.stroke();
      rr(ctx, -cw / 2, -h2, cw, h2, 11);
      if (textures.cactusSkin) {
        ctx.save();
        ctx.clip();
        ctx.translate(-cw / 2, -h2);
        ctx.fillStyle = textures.cactusSkin;
        ctx.fillRect(0, 0, cw, h2);
        ctx.restore();
      } else {
        ctx.fillStyle = "#6d8d55";
        ctx.fill();
      }
      const cg = ctx.createLinearGradient(-cw / 2, 0, cw / 2, 0);
      cg.addColorStop(0, "rgba(42, 68, 28, 0.35)");
      cg.addColorStop(0.35, "rgba(180, 225, 140, 0.28)");
      cg.addColorStop(1, "rgba(38, 60, 24, 0.45)");
      ctx.fillStyle = cg;
      ctx.fill();
      ctx.strokeStyle = "#365226";
      ctx.lineWidth = 3;
      ctx.stroke();
      const fy = -h2;
      for (let p = -1; p <= 1; p++) {
        ctx.beginPath();
        ctx.ellipse(p * 4.5, fy, 4.5, 7, p * 0.35, 0, TAU);
        ctx.fillStyle = p === 0 ? "#ff9ebb" : "#f2799b";
        ctx.fill();
        ctx.strokeStyle = "#5c2838";
        ctx.lineWidth = 1.6;
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(0, fy + 1, 2.8, 0, TAU);
      ctx.fillStyle = "#ffe066";
      ctx.fill();
    } else {
      const bh = o.h;
      const bg = ctx.createRadialGradient(0, -bh * 0.48, 4, 0, -bh * 0.42, bh * 0.65);
      bg.addColorStop(0, "rgba(186, 132, 68, 0.55)");
      bg.addColorStop(1, "rgba(110, 68, 28, 0)");
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.ellipse(0, -bh * 0.45, bh * 0.68, bh * 0.48, 0, 0, TAU);
      ctx.fill();
      ctx.lineCap = "round";
      for (let b = -3; b <= 3; b++) {
        ctx.beginPath();
        ctx.moveTo(b * 2, 0);
        ctx.quadraticCurveTo(
          b * 11,
          -bh * 0.48,
          b * 17,
          -bh * (0.68 + 0.1 * (b & 1 ? 1 : -1))
        );
        ctx.strokeStyle = b % 2 === 0 ? "#6e4720" : "#946534";
        ctx.lineWidth = 3.2;
        ctx.stroke();
      }
      for (let q = 0; q < 7; q++) {
        const qx = (q - 3) * 11;
        const qy = -bh * (0.48 + q * 37 % 5 * 0.085);
        ctx.beginPath();
        ctx.arc(qx, qy, 5.5, 0, TAU);
        ctx.fillStyle = q % 2 === 0 ? "#8c5a2b" : "#b57b42";
        ctx.fill();
        ctx.strokeStyle = "#4a2a10";
        ctx.lineWidth = 1.8;
        ctx.stroke();
      }
    }
    ctx.restore();
  }
  function drawRacer(ctx, r, camX, t) {
    const sx = START_X + (r.x - camX) * PPM;
    if (sx < -320 || sx > W + 320) return;
    const lane = clamp(Math.round(r.lane || 0), 0, LANE_DY.length - 1);
    const groundY = getLaneGroundY(lane);
    const sc = LANE_SCALE[lane];
    const y = groundY - r.h;
    ctx.save();
    const scaleH = 1 - clamp(r.h / 420, 0, 0.52);
    ctx.globalAlpha = 0.28 * scaleH;
    ctx.fillStyle = "#42220b";
    ctx.beginPath();
    ctx.ellipse(
      sx + 4,
      groundY + 3,
      88 * sc * scaleH * 1.25,
      11 * scaleH,
      0,
      0,
      TAU
    );
    ctx.fill();
    ctx.restore();
    if (r.isPlayer) {
      ctx.save();
      ctx.globalAlpha = 0.18 + Math.sin(t * 5) * 0.04;
      const pg = ctx.createRadialGradient(sx, groundY + 2, 4, sx, groundY + 2, 114);
      pg.addColorStop(0, "rgba(90, 245, 225, 0.65)");
      pg.addColorStop(1, "rgba(90, 245, 225, 0)");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.ellipse(sx, groundY + 2, 114, 22, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    ctx.save();
    drawJerboa(ctx, {
      x: sx,
      y,
      scale: sc,
      scarf: r.scarf,
      goggle: r.goggle,
      coatColor: r.coatColor,
      furTint: r.furTint,
      showRider: true,
      pose: {
        t: t + r.seedT,
        phase: r.phase,
        air: r.airborne ? clamp(r.h / 95, 0, 1) : 0,
        vy: r.vh,
        speed: r.speed,
        stumble: r.stumble > 0 ? clamp(r.stumble / 0.95, 0, 1) : 0,
        squash: r.squash
      }
    });
    ctx.restore();
    if (!r.isPlayer) {
      const ly = y - 348 * sc;
      ctx.save();
      ctx.fillStyle = "rgba(46, 24, 10, 0.78)";
      rr(ctx, sx - 46, ly - 17, 92, 24, 8);
      ctx.fill();
      ctx.strokeStyle = r.scarf;
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.restore();
      txt(ctx, `${r.place} \xB7 ${r.name}`, sx, ly, 12, "#fff0d2", "center", "700", 0.95);
    } else {
      const my = y - 256;
      ctx.save();
      ctx.fillStyle = "#5ef2df";
      ctx.strokeStyle = "#2a1608";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(sx - 9, my - 15);
      ctx.lineTo(sx + 9, my - 15);
      ctx.lineTo(sx, my - 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      txtOut(ctx, "\u0422\u042B", sx, my - 20, 13, "#b8fff3", "center", "800", 4, 0.95);
    }
  }
  function drawSpeedLines(ctx, p, t) {
    const k = clamp((p.speed - 24) / 14, 0, 1);
    if (k <= 0.02) return;
    const sprint = p.sprintFx > 0 ? 1 : 0;
    ctx.save();
    ctx.strokeStyle = "#fff5d8";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    for (let i = 0; i < 16; i++) {
      const y = 210 + i * 47 % 420;
      const x = ((i * 211 - t * (920 + i * 42)) % (W + 260) + W + 260) % (W + 260) - 130;
      const len = 34 + i % 5 * 28 + sprint * 44;
      ctx.globalAlpha = (0.06 + k * 0.16) * (i % 3 === 0 ? 1 : 0.65);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + len, y);
      ctx.stroke();
    }
    ctx.restore();
  }
  function drawVignetteAndFlash(ctx, hitFlash) {
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 0.95);
    vg.addColorStop(0, "rgba(40, 20, 6, 0)");
    vg.addColorStop(1, "rgba(28, 12, 3, 0.38)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
    if (hitFlash > 0) {
      ctx.save();
      ctx.globalAlpha = hitFlash * 0.52;
      const fg = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.82);
      fg.addColorStop(0, "rgba(255, 80, 40, 0)");
      fg.addColorStop(1, "rgba(220, 45, 18, 0.85)");
      ctx.fillStyle = fg;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }
  function renderWorldCanvas(ctx, state) {
    const textures = getTextures(ctx);
    const titleMode = state.mode === "title";
    const camX = titleMode ? state.t * 1.6 : state.camX;
    const camPx = camX * PPM;
    ctx.save();
    if (!titleMode && state.shake > 0.2) {
      ctx.translate(
        (Math.random() - 0.5) * state.shake,
        (Math.random() - 0.5) * state.shake * 0.7
      );
    }
    drawSky(ctx, camPx, state.t);
    drawMesas(ctx, camPx);
    drawDuneLayer(ctx, camPx, 0.1, "#e6b479", textures.sandFar, 38, HORIZON_Y - 38, 16e-4, 0.9);
    drawDuneLayer(ctx, camPx, 0.17, "#dca264", textures.sandMid, 28, HORIZON_Y - 18, 23e-4, 0.95);
    drawFarCacti(ctx, camPx);
    drawDuneLayer(ctx, camPx, 0.26, "#cf9252", textures.sandNear, 20, HORIZON_Y - 2, 31e-4, 1);
    drawGround(ctx, camX);
    if (titleMode) {
      const hx = 945;
      const hy = GROUND - 8;
      const p = state.player;
      ctx.save();
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = "#3f200a";
      ctx.beginPath();
      ctx.ellipse(hx + 6, hy + 4, 134, 15, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
      drawJerboa(ctx, {
        x: hx,
        y: hy,
        scale: 1.38,
        scarf: p ? p.scarf : "#28b5a8",
        goggle: p ? p.goggle : "#3de0d0",
        coatColor: p ? p.coatColor : "#f3d9a6",
        furTint: p ? p.furTint : "#eb9238",
        showRider: true,
        pose: {
          t: state.t,
          phase: 0,
          air: 0,
          vy: 0,
          speed: 0,
          // Standing firmly on both feet with gentle breathing squash!
          stumble: 0,
          squash: 1 + Math.sin(state.t * 3) * 0.018
        }
      });
      const shade = ctx.createLinearGradient(0, 0, 780, 0);
      shade.addColorStop(0, "rgba(34, 17, 6, 0.78)");
      shade.addColorStop(0.58, "rgba(34, 17, 6, 0.42)");
      shade.addColorStop(1, "rgba(34, 17, 6, 0)");
      ctx.fillStyle = shade;
      ctx.fillRect(0, 0, 780, H);
      ctx.restore();
      drawVignetteAndFlash(ctx, 0);
      return;
    }
    drawDistancePosts(ctx, camX);
    drawArch(ctx, 20, "\u0421\u0422\u0410\u0420\u0422", "#e0534b", camX, state.t);
    drawArch(ctx, RACE_LEN, "\u0424\u0418\u041D\u0418\u0428", "#2e9e7b", camX, state.t);
    for (let laneIdx = 3; laneIdx >= 0; laneIdx--) {
      const laneGroundY = getLaneGroundY(laneIdx);
      const laneScale = LANE_SCALE[laneIdx] / LANE_SCALE[0];
      for (let i = 0; i < state.obstacles.length; i++) {
        const o = state.obstacles[i];
        const osx = START_X + (o.x - camX) * PPM;
        if (osx > -140 && osx < W + 140) {
          if (laneIdx === 0) {
            drawSingleObstacleAt(ctx, o, osx, laneGroundY, 1);
          } else if ((i + laneIdx) % 2 === 0) {
            drawSingleObstacleAt(ctx, o, osx - laneIdx * 6, laneGroundY, laneScale * 0.78);
          }
        }
      }
      for (let rIdx = 0; rIdx < state.racers.length; rIdx++) {
        const r = state.racers[rIdx];
        if ((r.lane || 0) === laneIdx) {
          drawRacer(ctx, r, camX, state.t);
        }
      }
    }
    drawSpeedLines(ctx, state.player, state.t);
    for (let p = 0; p < state.particles.length; p++) {
      const pt = state.particles[p];
      if (!pt.active) continue;
      const px = START_X + (pt.x - camX) * PPM;
      const lifeK = clamp(pt.life / pt.max, 0, 1);
      ctx.save();
      ctx.globalAlpha = lifeK * (pt.kind === "spark" ? 0.95 : 0.58);
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(
        px,
        pt.y,
        pt.size * (pt.kind === "spark" ? 0.7 + lifeK * 0.5 : 1 + (1 - lifeK) * 0.4),
        0,
        TAU
      );
      ctx.fill();
      ctx.restore();
    }
    for (let q = 0; q < state.popups.length; q++) {
      const pop = state.popups[q];
      const a = clamp(pop.life / pop.max, 0, 1);
      txtOut(ctx, pop.text, pop.x, pop.y, 32, pop.color, "center", "800", 7, a);
    }
    ctx.restore();
    drawVignetteAndFlash(ctx, state.hitFlash);
    if (state.goFlash > 0) {
      const a = clamp(state.goFlash / 0.8, 0, 1);
      const scl = 1 + (1 - a) * 0.28;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.translate(W / 2, H / 2 - 36);
      ctx.scale(scl, scl);
      txtOut(ctx, "\u041F\u041E\u0428\u041B\u0418!", 0, 0, 96, "#8ff7d8", "center", "900", 14);
      ctx.restore();
    }
    if (state.mode === "countdown") {
      const n = Math.ceil(state.countdown - 0.6);
      if (n > 0) {
        const frac = 1 - (state.countdown - 0.6) % 1;
        const scale = 1 + (1 - frac) * 0.2;
        ctx.save();
        ctx.translate(W / 2, H / 2 - 40);
        ctx.scale(scale, scale);
        ctx.globalAlpha = 0.96;
        txtOut(ctx, String(n), 0, 0, 168, "#fff4d9", "center", "900", 16);
        ctx.restore();
      }
    }
  }

  // scripts/_standalone_entry.ts
  (function() {
    const canvas = document.getElementById("game");
    const ctx = canvas.getContext("2d");
    const MAX_PARTICLES = 260;
    const particles = Array.from({ length: MAX_PARTICLES }, () => ({
      active: false,
      kind: "dust",
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      life: 0,
      max: 1,
      size: 4,
      grav: 260,
      color: "#f2d6a6"
    }));
    let particleCursor = 0;
    const refImg = new Image();
    let refReady = false;
    refImg.onload = () => {
      refReady = true;
    };
    refImg.src = window.__JERBOA_REF_SRC__ || "assets/jerboa.png";
    function loadBest() {
      try {
        const v = parseFloat(localStorage.getItem("jerboa-race-best-v1") || "");
        return Number.isFinite(v) && v > 0 ? v : 0;
      } catch {
        return 0;
      }
    }
    function saveBest(v) {
      try {
        localStorage.setItem("jerboa-race-best-v1", String(v));
      } catch {
      }
    }
    const initRacers = createRacers(0);
    const G = {
      mode: "title",
      resumeMode: "race",
      t: 0,
      raceTime: 0,
      countdown: 3.6,
      lastCount: -1,
      goFlash: 0,
      camX: 0,
      shake: 0,
      hitFlash: 0,
      hitstop: 0,
      finishTimer: 0,
      seed: 20261104,
      skinIdx: 0,
      best: loadBest(),
      newRecord: false,
      auto: false,
      freeze: false,
      muted: false,
      obstacles: buildTrack(20261104),
      racers: initRacers.racers,
      player: initRacers.player,
      particles,
      popups: [],
      results: null,
      jumpQueued: false,
      sprintHeld: false,
      touchSprintHeld: false,
      ui: {}
    };
    function spawnDust(worldX, count, big = false, groundY = GROUND) {
      for (let i = 0; i < count; i++) {
        const p = G.particles[particleCursor];
        particleCursor = (particleCursor + 1) % MAX_PARTICLES;
        p.active = true;
        p.kind = "dust";
        p.x = worldX + (Math.random() - 0.5) * 1.6;
        p.y = groundY - 2 - Math.random() * 6;
        p.vx = -(20 + Math.random() * 90);
        p.vy = -(12 + Math.random() * (big ? 130 : 62));
        p.max = 0.48 + Math.random() * 0.42;
        p.life = p.max;
        p.size = 3.2 + Math.random() * (big ? 8.5 : 5.5);
        p.grav = 260;
        p.color = Math.random() > 0.35 ? "#f5dab0" : "#e6be86";
      }
    }
    function burstSpark(worldX, py, color = "#ffe27a") {
      for (let i = 0; i < 18; i++) {
        const p = G.particles[particleCursor];
        particleCursor = (particleCursor + 1) % MAX_PARTICLES;
        const a = Math.random() * TAU;
        const sp = 65 + Math.random() * 220;
        p.active = true;
        p.kind = "spark";
        p.x = worldX;
        p.y = py;
        p.vx = Math.cos(a) * sp;
        p.vy = Math.sin(a) * sp - 60;
        p.max = 0.42 + Math.random() * 0.38;
        p.life = p.max;
        p.size = 2.4 + Math.random() * 3.2;
        p.grav = 620;
        p.color = color;
      }
    }
    function pushPopup(text, color = "#fff3d8", worldX, py) {
      const sx = worldX != null ? START_X + (worldX - G.camX) * PPM : START_X + (G.player.x - G.camX) * PPM;
      for (let i = G.popups.length - 1; i >= 0; i--) {
        if (G.popups[i].text === text) G.popups.splice(i, 1);
      }
      G.popups.push({ text, color, x: sx, y: py != null ? py : GROUND - 365, life: 0.95, max: 0.95 });
      if (G.popups.length > 6) G.popups.shift();
    }
    function startRace(fromGesture = false) {
      if (fromGesture) Sfx.unlockFromGesture();
      else Sfx.init();
      const { racers, player } = createRacers(G.skinIdx);
      G.obstacles = buildTrack(G.seed);
      G.racers = racers;
      G.player = player;
      G.mode = "countdown";
      G.resumeMode = "countdown";
      G.countdown = 3.6;
      G.lastCount = -1;
      G.goFlash = 0;
      G.raceTime = 0;
      G.camX = player.x - 5;
      G.shake = 0;
      G.hitFlash = 0;
      G.hitstop = 0;
      G.finishTimer = 0;
      G.newRecord = false;
      G.results = null;
      G.jumpQueued = false;
      G.sprintHeld = false;
      G.touchSprintHeld = false;
      G.popups = [];
      for (let i = 0; i < G.particles.length; i++) G.particles[i].active = false;
    }
    function cycleSkin() {
      G.skinIdx = (G.skinIdx + 1) % PLAYER_SKINS.length;
      const sk = PLAYER_SKINS[G.skinIdx];
      G.player.scarf = sk.scarf;
      G.player.goggle = sk.goggle;
      G.player.coatColor = sk.coatColor;
      G.player.furTint = sk.furTint;
    }
    function update(dt) {
      G.t += dt;
      for (let i = 0; i < G.particles.length; i++) {
        const p = G.particles[i];
        if (!p.active) continue;
        p.life -= dt;
        if (p.life <= 0) {
          p.active = false;
          continue;
        }
        p.x += p.vx * dt / PPM;
        p.y += p.vy * dt;
        p.vy += p.grav * dt;
        p.vx *= 1 - dt * 1.5;
      }
      for (let i = G.popups.length - 1; i >= 0; i--) {
        const q = G.popups[i];
        q.life -= dt;
        q.y -= 26 * dt;
        if (q.life <= 0) G.popups.splice(i, 1);
      }
      G.shake *= Math.exp(-7 * dt);
      if (G.shake < 0.15) G.shake = 0;
      G.hitFlash = Math.max(0, G.hitFlash - dt * 2.2);
      if (G.hitstop > 0) {
        G.hitstop = Math.max(0, G.hitstop - dt);
        return;
      }
      if (G.mode === "title" || G.mode === "paused") return;
      if (G.mode === "results") {
        for (let i = 0; i < G.racers.length; i++) settleFinishedRacer(G.racers[i], dt, G.raceTime);
        return;
      }
      if (G.mode === "countdown") {
        G.countdown -= dt;
        const n = Math.ceil(G.countdown - 0.6);
        if (n > 0 && n !== G.lastCount) {
          G.lastCount = n;
          Sfx.count(false);
        }
        if (G.countdown <= 0.6) {
          G.mode = "race";
          G.countdown = 0;
          G.goFlash = 0.8;
          Sfx.count(true);
          pushPopup("\u041F\u041E\u0428\u041B\u0418!", "#8ff7d8");
        }
        for (let i = 0; i < G.racers.length; i++) {
          const r = G.racers[i];
          r.squash += (1 - r.squash) * Math.min(1, dt * 8);
          r.dustT -= dt;
          if (r.dustT <= 0) {
            r.dustT = 0.5 + Math.random() * 0.4;
            if (Math.random() < 0.6) spawnDust(r.x, 1, false, getLaneGroundY(r.lane));
          }
        }
        computePlaces(G.racers);
        G.camX = G.player.x - 5;
        return;
      }
      if (G.mode === "race") {
        G.raceTime += dt;
        G.goFlash = Math.max(0, G.goFlash - dt);
        const p = G.player;
        const pGroundY = getLaneGroundY(p.lane);
        let jump = G.jumpQueued;
        G.jumpQueued = false;
        let sprint = (G.sprintHeld || G.touchSprintHeld) && !G.auto;
        if (G.auto) {
          const dec = decideAutoPlayer(p, G.obstacles, G.raceTime);
          jump = dec.jump;
          sprint = dec.sprint;
        }
        const pEv = advanceRacer(p, dt, G.raceTime, G.obstacles, jump, sprint, 1);
        if (pEv.jumped) {
          if (pEv.perfect) {
            burstSpark(p.x, pGroundY - p.h - 8, "#ffe27a");
            Sfx.perfect(p.combo);
            pushPopup(p.flow >= 1.5 ? "\u0418\u0414\u0415\u0410\u041B\u042C\u041D\u041E! \xD7" + Math.round(p.flow) : "\u0418\u0414\u0415\u0410\u041B\u042C\u041D\u041E!", "#ffe89a");
            G.shake = Math.max(G.shake, 2.6);
          } else Sfx.hop();
          spawnDust(p.x, 9, false, pGroundY);
        }
        if (pEv.landed && !pEv.jumped) {
          Sfx.land();
          spawnDust(p.x, 14, true, pGroundY);
          G.shake = Math.max(G.shake, 2.2);
        }
        if (pEv.spawnedRunDust) spawnDust(p.x - 1.4, 2, false, pGroundY);
        if (pEv.hitObstacle) {
          spawnDust(p.x, 22, true, pGroundY);
          burstSpark(p.x + 1, pGroundY - 28, "#ff9a7a");
          G.shake = 14;
          G.hitFlash = 0.55;
          G.hitstop = 0.045;
          Sfx.stumble();
          pushPopup("\u041E\u0419!", "#ff9a7a");
        }
        for (let j = 1; j < G.racers.length; j++) {
          const ai = G.racers[j];
          const aiGroundY = getLaneGroundY(ai.lane);
          if (ai.finished) {
            if (settleFinishedRacer(ai, dt, G.raceTime)) spawnDust(ai.x, 8, true, aiGroundY);
            continue;
          }
          const aiEv = stepAIRacer(ai, p.x, dt, G.raceTime, G.obstacles);
          if (aiEv.jumped) {
            spawnDust(ai.x, 5, false, aiGroundY);
            if (aiEv.perfect) burstSpark(ai.x, aiGroundY - ai.h - 8, "#ffe27a");
          }
          if (aiEv.landed) spawnDust(ai.x, 8, true, aiGroundY);
          if (aiEv.spawnedRunDust) spawnDust(ai.x - 1.4, 1, false, aiGroundY);
          if (aiEv.hitObstacle) spawnDust(ai.x, 12, true, aiGroundY);
        }
        for (let f = 0; f < G.racers.length; f++) {
          const r = G.racers[f];
          if (!r.finished && r.x >= RACE_LEN) {
            r.finished = true;
            r.finishTime = G.raceTime;
            if (r.isPlayer) {
              G.mode = "finish";
              G.finishTimer = 1.35;
              p.speed *= 0.65;
              Sfx.finish();
              G.shake = 6;
              G.newRecord = !G.best || r.finishTime < G.best;
              if (G.newRecord) {
                G.best = r.finishTime;
                saveBest(G.best);
              }
              pushPopup("\u0424\u0418\u041D\u0418\u0428!", "#ffe89a");
            }
          }
        }
        G.camX += (p.x - G.camX) * Math.min(1, dt * 9);
        computePlaces(G.racers);
        return;
      }
      if (G.mode === "finish") {
        G.finishTimer -= dt;
        if (settleFinishedRacer(G.player, dt, G.raceTime)) {
          spawnDust(G.player.x, 12, true, getLaneGroundY(G.player.lane));
        }
        for (let j = 1; j < G.racers.length; j++) {
          const ai = G.racers[j];
          if (ai.finished) settleFinishedRacer(ai, dt, G.raceTime);
          else {
            stepAIRacer(ai, G.player.x, dt, G.raceTime, G.obstacles);
            if (ai.x >= RACE_LEN) {
              ai.finished = true;
              ai.finishTime = G.raceTime + (1.35 - G.finishTimer);
            }
          }
        }
        G.camX += (G.player.x - G.camX) * Math.min(1, dt * 4);
        if (G.finishTimer <= 0) {
          G.results = buildResults(G.racers, G.player, G.raceTime, G.newRecord);
          G.mode = "results";
        }
      }
    }
    function drawCanvasOverlays() {
      const p = G.player;
      if (G.mode === "title") {
        txtOut(ctx, "\u0422\u0423\u0428\u041A\u0410\u041D\u0427\u0418\u041A\u0418", 74, 162, 76, "#fff2d4", "left", "900", 12);
        txtOut(ctx, "\u041D\u0410 \u0421\u0422\u0410\u0420\u0422\u0415", 76, 240, 76, "#ffca7a", "left", "900", 12);
        txt(ctx, "\u0413\u041E\u041D\u041A\u0418 \u041F\u041E \u041F\u0423\u0421\u0422\u042B\u041D\u0415 \xB7 850 \u041C \xB7 4 \u0414\u041E\u0420\u041E\u0416\u041A\u0418", 80, 282, 17, "#ffdca8", "left", "800", 0.9);
        txt(ctx, "\u041F\u0440\u044B\u0433\u0430\u0439 \u0432 \u0442\u0430\u043A\u0442 \u043F\u0440\u0438\u0437\u0435\u043C\u043B\u0435\u043D\u0438\u044F \u2014 \u043B\u043E\u0432\u0438 \u0437\u043E\u043B\u043E\u0442\u043E\u0439 \u043F\u043E\u0442\u043E\u043A \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u0438.", 80, 328, 17, "#ffe9c8", "left", "600", 0.95);
        txt(ctx, "\u041F\u0435\u0440\u0435\u043F\u0440\u044B\u0433\u0438\u0432\u0430\u0439 \u0441\u0430\u0433\u0443\u0430\u0440\u043E \u0438 \u0432\u0430\u043B\u0443\u043D\u044B, \u0443\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0439 \u0441\u043F\u0443\u0440\u0442 \u0438 \u043E\u0431\u0433\u043E\u043D\u0438 \u0441\u043E\u043F\u0435\u0440\u043D\u0438\u043A\u043E\u0432!", 80, 354, 17, "#ffe9c8", "left", "600", 0.95);
        const sk = PLAYER_SKINS[G.skinIdx];
        ctx.save();
        ctx.fillStyle = "rgba(54, 28, 12, 0.85)";
        rr(ctx, 80, 384, 340, 42, 12);
        ctx.fill();
        ctx.strokeStyle = sk.scarf;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
        txt(ctx, "\u042D\u041A\u0418\u041F\u0418\u0420\u041E\u0412\u041A\u0410 [C]: " + sk.title.toUpperCase(), 98, 410, 14, "#fff1cf", "left", "800");
        G.ui.skinBtn = [80, 384, 340, 42];
        const bx = 80, by = 456, bw = 240, bh = 62;
        ctx.save();
        ctx.fillStyle = "#f29d38";
        rr(ctx, bx, by, bw, bh, 16);
        ctx.fill();
        ctx.strokeStyle = "#ffe0a3";
        ctx.lineWidth = 3;
        ctx.stroke();
        txt(ctx, "\u0421\u0422\u0410\u0420\u0422 \xB7 \u041F\u0420\u041E\u0411\u0415\u041B", bx + bw / 2, by + 39, 22, "#2e1505", "center", "900");
        ctx.restore();
        G.ui.startBtn = [bx, by, bw, bh];
        txt(ctx, "\u041F\u0420\u041E\u0411\u0415\u041B / \u041A\u041B\u0418\u041A \u2014 \u043F\u0440\u044B\u0436\u043E\u043A \xB7 SHIFT \u2014 \u0441\u043F\u0443\u0440\u0442 \xB7 C \u2014 \u0446\u0432\u0435\u0442 \xB7 P \u2014 \u043F\u0430\u0443\u0437\u0430 \xB7 M \u2014 \u0437\u0432\u0443\u043A", 80, 682, 14, "#ffe4b5", "left", "700", 0.85);
        if (refReady) {
          ctx.save();
          ctx.translate(1180, 96);
          ctx.rotate(0.05);
          ctx.fillStyle = "#fff9eb";
          rr(ctx, -58, -58, 116, 116, 12);
          ctx.fill();
          ctx.strokeStyle = "#6e3f19";
          ctx.lineWidth = 2.5;
          ctx.stroke();
          ctx.drawImage(refImg, -50, -50, 100, 100);
          ctx.restore();
        }
        return;
      }
      if (G.mode === "countdown" || G.mode === "race" || G.mode === "finish") {
        ctx.save();
        ctx.fillStyle = "rgba(54, 28, 12, 0.88)";
        rr(ctx, 22, 18, 210, 78, 14);
        ctx.fill();
        ctx.strokeStyle = "rgba(235, 182, 112, 0.4)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
        txt(ctx, "\u041C\u0415\u0421\u0422\u041E", 38, 42, 12, "#e9c89a", "left", "800");
        txtOut(ctx, p.place + " / 4", 38, 82, 36, "#fff3d6", "left", "900", 6);
        txt(ctx, Math.round(G.raceTime) + " \u0441", 162, 78, 22, "#ffe4b5", "left", "800");
        const bx = 330, by = 38, bw = 600, bh = 12;
        ctx.save();
        ctx.fillStyle = "rgba(54, 28, 12, 0.88)";
        rr(ctx, bx - 16, by - 16, bw + 32, 44, 14);
        ctx.fill();
        ctx.fillStyle = "#241205";
        rr(ctx, bx, by, bw, bh, 6);
        ctx.fill();
        const prog = clamp(p.x / RACE_LEN, 0, 1);
        ctx.fillStyle = "#f29d38";
        rr(ctx, bx, by, Math.max(6, bw * prog), bh, 6);
        ctx.fill();
        for (let i = 0; i < G.racers.length; i++) {
          const r = G.racers[i];
          const dx = bx + bw * clamp(r.x / RACE_LEN, 0, 1);
          ctx.beginPath();
          ctx.arc(dx, by + bh / 2, r.isPlayer ? 7.5 : 5.5, 0, TAU);
          ctx.fillStyle = r.scarf;
          ctx.fill();
          ctx.lineWidth = 2;
          ctx.strokeStyle = r.isPlayer ? "#fffbe6" : "#2b1506";
          ctx.stroke();
        }
        ctx.restore();
        ctx.save();
        ctx.fillStyle = "rgba(54, 28, 12, 0.88)";
        rr(ctx, W - 188, 18, 166, 78, 14);
        ctx.fill();
        ctx.strokeStyle = "rgba(235, 182, 112, 0.4)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
        txt(ctx, "\u0421\u041A\u041E\u0420\u041E\u0421\u0422\u042C \xB7 \u041A\u041C/\u0427", W - 38, 42, 12, "#e9c89a", "right", "800");
        txtOut(ctx, String(Math.round(p.speed * 3.6)), W - 38, 82, 38, "#fff3d6", "right", "900", 6);
        ctx.save();
        ctx.fillStyle = "rgba(54, 28, 12, 0.88)";
        rr(ctx, 22, H - 118, 254, 98, 14);
        ctx.fill();
        ctx.strokeStyle = "rgba(235, 182, 112, 0.4)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
        txt(ctx, "\u041F\u041E\u0422\u041E\u041A \u0421\u041A\u041E\u0420\u041E\u0421\u0422\u0418 \xD7" + (Math.floor(p.flow) + 1), 38, H - 94, 12, "#ffdda9", "left", "800");
        for (let f = 0; f < 5; f++) {
          const on = p.flow >= f + 0.5;
          ctx.fillStyle = on ? "#ffd166" : "#211004";
          rr(ctx, 38 + f * 44, H - 86, 38, 14, 4);
          ctx.fill();
        }
        txt(ctx, "\u0421\u0418\u041B\u042B \u0414\u041B\u042F \u0421\u041F\u0423\u0420\u0422\u0410", 38, H - 48, 12, "#ffdda9", "left", "800");
        ctx.fillStyle = "#211004";
        rr(ctx, 38, H - 40, 218, 12, 5);
        ctx.fill();
        ctx.fillStyle = "#38c9a8";
        rr(ctx, 38, H - 40, Math.max(4, 218 * (p.stamina / 100)), 12, 5);
        ctx.fill();
      }
      if (G.mode === "paused") {
        ctx.fillStyle = "rgba(20, 9, 2, 0.72)";
        ctx.fillRect(0, 0, W, H);
        txtOut(ctx, "\u041F\u0410\u0423\u0417\u0410", W / 2, H / 2 - 20, 72, "#fff2d4", "center", "900", 12);
        txt(ctx, "P \u2014 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \xB7 R \u2014 \u0437\u0430\u043D\u043E\u0432\u043E \xB7 ESC \u2014 \u0432 \u043C\u0435\u043D\u044E", W / 2, H / 2 + 40, 20, "#ffe4b5", "center", "700");
      }
      if (G.mode === "results" && G.results) {
        const res = G.results;
        ctx.fillStyle = "rgba(20, 9, 2, 0.72)";
        ctx.fillRect(0, 0, W, H);
        const pw = 640, ph = 430, px = (W - pw) / 2, py = 135;
        ctx.fillStyle = "rgba(52, 28, 12, 0.96)";
        rr(ctx, px, py, pw, ph, 24);
        ctx.fill();
        ctx.strokeStyle = "rgba(242, 192, 120, 0.45)";
        ctx.lineWidth = 2.5;
        ctx.stroke();
        txt(ctx, "\u0424\u0418\u041D\u0418\u0428\u041D\u042B\u0419 \u041F\u0420\u041E\u0422\u041E\u041A\u041E\u041B \xB7 850 \u041C", W / 2, py + 52, 16, "#ffcf8a", "center", "800");
        txtOut(ctx, res.playerPlace + " \u041C\u0415\u0421\u0422\u041E", W / 2, py + 116, 58, "#ffd166", "center", "900", 10);
        for (let i = 0; i < res.rows.length; i++) {
          const row = res.rows[i];
          const y = py + 168 + i * 42;
          if (row.isPlayer) {
            ctx.fillStyle = "rgba(40, 181, 168, 0.22)";
            rr(ctx, px + 44, y - 26, pw - 88, 36, 10);
            ctx.fill();
          }
          txt(ctx, row.place + ". " + row.name, px + 64, y, 19, row.isPlayer ? "#d8fff8" : "#ffeac8", "left", "800");
          txt(ctx, row.time.toFixed(1) + " \u0441", px + pw - 64, y, 19, row.isPlayer ? "#d8fff8" : "#ffeac8", "right", "800");
        }
        const b1 = [px + 64, py + ph - 78, 250, 52];
        const b2 = [px + pw - 64 - 210, py + ph - 78, 210, 52];
        G.ui.restart = b1;
        G.ui.menu = b2;
        ctx.fillStyle = "#f29d38";
        rr(ctx, b1[0], b1[1], b1[2], b1[3], 14);
        ctx.fill();
        txt(ctx, "\u0415\u0429\u0401 \u0420\u0410\u0417 \xB7 \u041F\u0420\u041E\u0411\u0415\u041B", b1[0] + b1[2] / 2, b1[1] + 33, 18, "#2e1505", "center", "900");
        ctx.fillStyle = "rgba(88, 48, 20, 0.9)";
        rr(ctx, b2[0], b2[1], b2[2], b2[3], 14);
        ctx.fill();
        txt(ctx, "\u0412 \u041C\u0415\u041D\u042E \xB7 ESC", b2[0] + b2[2] / 2, b2[1] + 33, 17, "#ffe9c4", "center", "800");
      }
    }
    function fitCanvas() {
      const vw = window.innerWidth, vh = window.innerHeight;
      const w = Math.min(vw, vh * 16 / 9);
      const h = w * 9 / 16;
      canvas.style.width = Math.round(w) + "px";
      canvas.style.height = Math.round(h) + "px";
      const dpr = Math.min(1.5, window.devicePixelRatio || 1);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    }
    function inRect(p, r) {
      return r && p.x >= r[0] && p.x <= r[0] + r[2] && p.y >= r[1] && p.y <= r[1] + r[3];
    }
    window.addEventListener("resize", fitCanvas);
    fitCanvas();
    canvas.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      Sfx.unlockFromGesture();
      const rect = canvas.getBoundingClientRect();
      const p = { x: (e.clientX - rect.left) * (W / rect.width), y: (e.clientY - rect.top) * (H / rect.height) };
      if (G.mode === "title") {
        if (inRect(p, G.ui.skinBtn)) {
          cycleSkin();
          return;
        }
        startRace(true);
        return;
      }
      if (G.mode === "results") {
        if (inRect(p, G.ui.restart)) {
          startRace(true);
          return;
        }
        if (inRect(p, G.ui.menu)) {
          G.mode = "title";
          return;
        }
        return;
      }
      if (G.mode === "paused") {
        G.mode = G.resumeMode || "race";
        return;
      }
      if (G.mode === "race") G.jumpQueued = true;
    });
    window.addEventListener("keydown", (e) => {
      const k = e.code;
      if (k === "Space" || k === "ArrowUp" || k === "KeyW") e.preventDefault();
      if (e.repeat) return;
      Sfx.unlockFromGesture();
      if (k === "KeyM") {
        G.muted = !G.muted;
        Sfx.setMuted(G.muted);
        return;
      }
      if (G.mode === "title") {
        if (k === "KeyC") {
          cycleSkin();
          return;
        }
        if (k === "Space" || k === "Enter" || k === "ArrowUp") startRace(true);
        return;
      }
      if (G.mode === "results") {
        if (k === "Space" || k === "Enter" || k === "KeyR") startRace(true);
        if (k === "Escape") G.mode = "title";
        return;
      }
      if (k === "KeyP" || k === "Escape") {
        if (G.mode === "paused") G.mode = G.resumeMode || "race";
        else {
          G.resumeMode = G.mode;
          G.mode = "paused";
        }
        return;
      }
      if (k === "KeyR") {
        startRace(true);
        return;
      }
      if (k === "ShiftLeft" || k === "ShiftRight") G.sprintHeld = true;
      if (k === "Space" || k === "ArrowUp" || k === "KeyW") {
        if (G.mode === "race") G.jumpQueued = true;
      }
    });
    window.addEventListener("keyup", (e) => {
      if (e.code === "ShiftLeft" || e.code === "ShiftRight") G.sprintHeld = false;
    });
    let last = 0;
    function loop(now) {
      const dt = last ? Math.min(0.05, (now - last) / 1e3) : 0.016;
      last = now;
      if (!G.freeze) update(dt);
      else G.t += dt;
      const dpr = Math.min(1.5, window.devicePixelRatio || 1);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      renderWorldCanvas(ctx, G);
      drawCanvasOverlays();
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
  })();
})();
